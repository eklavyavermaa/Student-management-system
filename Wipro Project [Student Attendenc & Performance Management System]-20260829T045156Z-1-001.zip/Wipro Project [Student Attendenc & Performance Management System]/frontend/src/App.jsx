import React, { useState, useEffect } from 'react';
import {
    ThemeProvider,
    createTheme,
    CssBaseline,
    Container,
    Box,
    Paper,
    Typography,
    TextField,
    Button,
    Grid,
    Card,
    CardContent,
    Tabs,
    Tab,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    IconButton,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Snackbar,
    Alert,
    CircularProgress,
    Chip,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    Divider,
    Avatar,
    AppBar,
    Toolbar,
    Menu,
    Tooltip,
    Badge,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Fade,
    Grow,
    LinearProgress
} from '@mui/material';
import {
    Login,
    PersonAdd,
    Dashboard as DashIcon,
    People,
    AssignmentTurnedIn,
    Grade,
    Warning,
    Assessment,
    ExitToApp,
    Add,
    Delete,
    Edit,
    CloudUpload,
    Search,
    School,
    Email,
    Phone,
    AssignmentInd,
    FileDownload,
    ExpandMore,
    AccountCircle
} from '@mui/icons-material';

import { authAPI, studentAPI, courseAPI, attendanceAPI, marksAPI, reportAPI } from './api';

// Create a professional light premium theme matching Outfit/Inter font styling
const theme = createTheme({
    palette: {
        mode: 'light',
        primary: {
            main: '#4f46e5', // Indigo Accent
            contrastText: '#ffffff',
        },
        secondary: {
            main: '#0d9488', // Teal Accent
        },
        error: {
            main: '#e11d48', // Rose Red
        },
        warning: {
            main: '#d97706', // Amber Accent
        },
        background: {
            default: '#f8fafc', // Slate 50
            paper: '#ffffff', // White
        },
        text: {
            primary: '#0f172a', // Slate 900
            secondary: '#475569', // Slate 600
        },
    },
    typography: {
        fontFamily: "'Outfit', 'Inter', sans-serif",
        h4: {
            fontWeight: 800,
            letterSpacing: '-0.025em',
            color: '#0f172a',
        },
        h5: {
            fontWeight: 700,
            letterSpacing: '-0.02em',
            color: '#0f172a',
        },
        h6: {
            fontWeight: 700,
            color: '#0f172a',
        },
        button: {
            fontWeight: 600,
            textTransform: 'none',
        },
    },
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: '8px',
                    padding: '8px 16px',
                    transition: 'all 0.2s ease-in-out',
                    boxShadow: 'none',
                    '&:hover': {
                        transform: 'translateY(-1px)',
                        boxShadow: '0 4px 12px 0 rgba(79, 70, 229, 0.12)',
                    },
                },
            },
        },
        MuiPaper: {
            styleOverrides: {
                root: {
                    backgroundImage: 'none',
                    borderRadius: '16px',
                    border: '1px solid rgba(0, 0, 0, 0.05)',
                    boxShadow: '0 4px 20px 0 rgba(0, 0, 0, 0.015)',
                },
            },
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    backgroundImage: 'none',
                    borderRadius: '16px',
                    border: '1px solid rgba(0, 0, 0, 0.05)',
                    boxShadow: '0 4px 20px 0 rgba(0, 0, 0, 0.015)',
                },
            },
        },
        MuiTableCell: {
            styleOverrides: {
                head: {
                    fontWeight: 700,
                    backgroundColor: '#f1f5f9', // Slate 100
                    color: '#0f172a',
                },
            },
        },
        MuiAppBar: {
            styleOverrides: {
                root: {
                    backgroundColor: 'rgba(255, 255, 255, 0.8)',
                    color: '#0f172a',
                    borderBottom: '1px solid rgba(0, 0, 0, 0.05)',
                },
            },
        },
    },
});

function App() {
    // --- State Management ---
    const [user, setUser] = useState(null);
    const [view, setView] = useState('auth'); // 'auth' or 'dashboard'
    const [authTab, setAuthTab] = useState(0); // 0=Login, 1=Student Register, 2=Faculty Register
    const [facultyTab, setFacultyTab] = useState(0); // 0=Overview, 1=Students, 2=Attendance, 3=Marks, 4=Shortage, 5=Reports
    const [studentTab, setStudentTab] = useState(0); // 0=Profile, 1=Attendance, 2=Grades, 3=Report Card

    // Profile Dropdown
    const [profileAnchorEl, setProfileAnchorEl] = useState(null);

    // Forms
    const [loginForm, setLoginForm] = useState({ username: '', password: '' });
    const [studentRegForm, setStudentRegForm] = useState({
        username: '', password: '', name: '', email: '', phone: '', rollNo: '', department: ''
    });
    const [facultyRegForm, setFacultyRegForm] = useState({ username: '', password: '' });
    const [studentForm, setStudentForm] = useState({ id: null, rollNo: '', name: '', email: '', phone: '', department: '' });
    const [courseForm, setCourseForm] = useState({ courseCode: '', courseName: '' });

    // Selections
    const [selectedCourse, setSelectedCourse] = useState('');
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [attendanceMap, setAttendanceMap] = useState({}); // studentId -> status

    // Marks Form
    const [marksForm, setMarksForm] = useState({ studentId: '', courseId: '', examType: 'MST_1', marksObtained: '', maxMarks: '' });

    // Reports Search
    const [reportSearchRoll, setReportSearchRoll] = useState('');
    const [generatedReport, setGeneratedReport] = useState(null);

    // List caches
    const [students, setStudents] = useState([]);
    const [courses, setCourses] = useState([]);
    const [tempStudents, setTempStudents] = useState([]);
    const [shortageReport, setShortageReport] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');

    // Student personal views
    const [myProfile, setMyProfile] = useState(null);
    const [myAttendance, setMyAttendance] = useState([]);
    const [myMarks, setMyMarks] = useState([]);
    const [myReport, setMyReport] = useState(null);

    // Feedback
    const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
    const [loading, setLoading] = useState(false);
    
    // Dialogs
    const [studentDialog, setStudentDialog] = useState({ open: false, mode: 'add' }); // 'add', 'edit', 'temp'
    const [courseDialog, setCourseDialog] = useState(false);

    // --- Side Effects ---
    useEffect(() => {
        if (user) {
            fetchData();
        }
    }, [user]);

    const showNotification = (message, severity = 'info') => {
        setNotification({ open: true, message, severity });
    };

    const handleNotificationClose = () => {
        setNotification({ ...notification, open: false });
    };

    const handleOpenProfileMenu = (e) => {
        setProfileAnchorEl(e.currentTarget);
    };

    const handleCloseProfileMenu = () => {
        setProfileAnchorEl(null);
    };

    // --- API Calls ---
    const fetchData = async () => {
        setLoading(true);
        try {
            if (user.role === 'FACULTY') {
                const [studRes, courseRes, tempRes, shortageRes] = await Promise.all([
                    studentAPI.getAll(),
                    courseAPI.getAll(),
                    studentAPI.getTemp(),
                    attendanceAPI.getShortageReport()
                ]);
                setStudents(studRes.data);
                setCourses(courseRes.data);
                setTempStudents(tempRes.data);
                setShortageReport(shortageRes.data);
            } else if (user.role === 'STUDENT' && user.studentId) {
                const [profileRes, attRes, marksRes, reportRes, courseRes] = await Promise.all([
                    studentAPI.getById(user.studentId),
                    attendanceAPI.getHistory(user.studentId),
                    marksAPI.getHistory(user.studentId),
                    reportAPI.generate(user.username),
                    courseAPI.getAll()
                ]);
                setMyProfile(profileRes.data);
                setMyAttendance(attRes.data);
                setMyMarks(marksRes.data);
                setMyReport(reportRes.data);
                setCourses(courseRes.data);
            }
        } catch (error) {
            console.error('Error fetching data', error);
            showNotification(error.response?.data?.error || 'Failed to sync data with server.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            const res = await authAPI.login(loginForm.username, loginForm.password);
            setUser(res.data);
            setView('dashboard');
            showNotification('Welcome back, ' + res.data.username + '!', 'success');
        } catch (error) {
            showNotification(error.response?.data?.error || 'Authentication failed.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleStudentRegister = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await authAPI.registerStudent(studentRegForm);
            showNotification('Registration successful! Please login.', 'success');
            setAuthTab(0); // Switch to login
        } catch (error) {
            showNotification(error.response?.data?.error || 'Registration failed.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleFacultyRegister = async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
            await authAPI.registerFaculty(facultyRegForm.username, facultyRegForm.password);
            showNotification('Faculty account created! Please login.', 'success');
            setAuthTab(0); // Switch to login
        } catch (error) {
            showNotification(error.response?.data?.error || 'Registration failed.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleAddOrEditStudent = async (e) => {
        e.preventDefault();
        try {
            if (studentDialog.mode === 'add') {
                await studentAPI.add(studentForm);
                showNotification('Student profile created successfully.', 'success');
            } else {
                await studentAPI.update(studentForm);
                showNotification('Student details updated successfully.', 'success');
            }
            setStudentDialog({ open: false, mode: 'add' });
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Action failed.', 'error');
        }
    };

    const handleAddStudentTemp = async () => {
        try {
            await studentAPI.addTemp(studentForm);
            showNotification('Student profile cached inside temporary buffer.', 'success');
            setStudentDialog({ open: false, mode: 'add' });
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to cache student.', 'error');
        }
    };

    const handleCommitTempStudents = async () => {
        setLoading(true);
        try {
            const res = await studentAPI.commitTemp();
            showNotification(res.data.message || 'Committed successfully.', 'success');
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to commit buffer.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleClearTempStudents = async () => {
        try {
            await studentAPI.clearTemp();
            showNotification('Temporary buffer cleared.', 'success');
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to clear buffer.', 'error');
        }
    };

    const handleDeleteStudent = async (rollNo) => {
        if (!window.confirm(`Are you sure you want to delete student: ${rollNo}? This will delete all attendance/marks.`)) {
            return;
        }
        try {
            await studentAPI.delete(rollNo);
            showNotification('Student profile deleted.', 'success');
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to delete student.', 'error');
        }
    };

    const handleAddCourse = async (e) => {
        e.preventDefault();
        try {
            await courseAPI.add(courseForm);
            showNotification('Course registered successfully.', 'success');
            setCourseDialog(false);
            setCourseForm({ courseCode: '', courseName: '' });
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to register course.', 'error');
        }
    };

    const handleSearch = async () => {
        try {
            const res = await studentAPI.search(searchQuery);
            setStudents(res.data);
        } catch (error) {
            showNotification('Failed to execute search.', 'error');
        }
    };

    const handleMarkAttendanceBatch = async () => {
        if (!selectedCourse) {
            showNotification('Please select a course.', 'warning');
            return;
        }
        setLoading(true);
        try {
            await attendanceAPI.markBatch(selectedCourse, selectedDate, attendanceMap);
            showNotification('Batch attendance marked successfully.', 'success');
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to log attendance.', 'error');
        } finally {
            setLoading(false);
        }
    };

    const handleRecordMarks = async (e) => {
        e.preventDefault();
        try {
            await marksAPI.record(
                marksForm.studentId,
                marksForm.courseId,
                marksForm.examType,
                parseFloat(marksForm.marksObtained),
                parseFloat(marksForm.maxMarks)
            );
            showNotification('Marks recorded successfully.', 'success');
            setMarksForm({ studentId: '', courseId: '', examType: 'MST_1', marksObtained: '', maxMarks: '' });
            fetchData();
        } catch (error) {
            showNotification(error.response?.data?.error || 'Failed to record marks.', 'error');
        }
    };

    const handleSearchReport = async () => {
        if (!reportSearchRoll.trim()) return;
        setLoading(true);
        try {
            const res = await reportAPI.generate(reportSearchRoll.trim());
            setGeneratedReport(res.data);
        } catch (error) {
            showNotification(error.response?.data?.error || 'Report lookup failed.', 'error');
            setGeneratedReport(null);
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = () => {
        handleCloseProfileMenu();
        setUser(null);
        setView('auth');
        setLoginForm({ username: '', password: '' });
        setGeneratedReport(null);
        setMyProfile(null);
        setMyReport(null);
        showNotification('Successfully logged out.');
    };

    // --- Helpers ---
    const getCourseName = (courseId) => {
        const found = courses.find(c => c.id === courseId);
        return found ? found.courseName : 'Unknown Course';
    };

    const getCourseCode = (courseId) => {
        const found = courses.find(c => c.id === courseId);
        return found ? found.courseCode : '';
    };

    // --- Shared App Bar ---
    const renderAppBar = () => (
        <AppBar position="sticky" elevation={0} sx={{ borderBottom: '1px solid rgba(0, 0, 0, 0.05)', bgcolor: 'rgba(255, 255, 255, 0.8)', backdropFilter: 'blur(16px)' }}>
            <Container maxWidth="lg">
                <Toolbar disableGutters sx={{ justifyContent: 'space-between' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <img src="/logo.svg" alt="logo" style={{ height: '36px', width: '36px' }} />
                        <Typography variant="h6" sx={{ fontWeight: 800, background: 'linear-gradient(90deg, #4f46e5 0%, #0d9488 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', display: { xs: 'none', sm: 'block' } }}>
                            SAPMS Portal
                        </Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <Chip label={user.role} color={user.role === 'FACULTY' ? 'primary' : 'secondary'} size="small" sx={{ fontWeight: 800, px: 1 }} />
                        <Tooltip title="Account profile">
                            <IconButton onClick={handleOpenProfileMenu} sx={{ p: 0.5 }}>
                                <Avatar sx={{ bgcolor: user.role === 'FACULTY' ? 'primary.main' : 'secondary.main', width: 36, height: 36, fontWeight: 700, color: '#fff' }}>
                                    {user.username.charAt(0).toUpperCase()}
                                </Avatar>
                            </IconButton>
                        </Tooltip>
                        <Menu
                            anchorEl={profileAnchorEl}
                            open={Boolean(profileAnchorEl)}
                            onClose={handleCloseProfileMenu}
                            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
                        >
                            <MenuItem disabled sx={{ opacity: 0.95 }}>
                                <Box sx={{ py: 0.5 }}>
                                    <Typography variant="caption" color="text.secondary">Logged in as</Typography>
                                    <Typography variant="subtitle2" sx={{ fontWeight: 700, mt: -0.5 }}>{user.username}</Typography>
                                </Box>
                            </MenuItem>
                            <Divider />
                            <MenuItem onClick={handleLogout} sx={{ color: 'error.main' }}>
                                <ExitToApp sx={{ mr: 1.5, fontSize: 20 }} /> Logout
                            </MenuItem>
                        </Menu>
                    </Box>
                </Toolbar>
            </Container>
        </AppBar>
    );

    // --- Render Views ---

    // Auth screen (Login/Register)
    const renderAuthScreen = () => (
        <Container maxWidth="sm" sx={{ mt: 8, mb: 6 }} className="animate-fade-in">
            <Box sx={{ textAlign: 'center', mb: 4 }}>
                <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                    <img src="/logo.svg" alt="logo" style={{ height: '76px', width: '76px' }} />
                </Box>
                <Typography variant="h4" gutterBottom sx={{ fontWeight: 900, color: '#0f172a' }}>
                    SAPMS Backend Portal
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    Student Attendance & Performance Management System
                </Typography>
            </Box>
            <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                <Tabs
                    value={authTab}
                    onChange={(e, val) => setAuthTab(val)}
                    variant="fullWidth"
                    textColor="primary"
                    indicatorColor="primary"
                    sx={{ mb: 4 }}
                >
                    <Tab label="Login" icon={<Login />} iconPosition="start" />
                    <Tab label="Student Registry" icon={<PersonAdd />} iconPosition="start" />
                    <Tab label="Faculty Sign Up" icon={<AssignmentInd />} iconPosition="start" />
                </Tabs>

                {authTab === 0 && (
                    <Box component="form" onSubmit={handleLogin}>
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            label="Username"
                            value={loginForm.username}
                            onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                        />
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            label="Password"
                            type="password"
                            value={loginForm.password}
                            onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                        />
                        <Button type="submit" fullWidth variant="contained" color="primary" sx={{ mt: 4, py: 1.5 }}>
                            Sign In
                        </Button>
                    </Box>
                )}

                {authTab === 1 && (
                    <Box component="form" onSubmit={handleStudentRegister}>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Name"
                                    value={studentRegForm.name}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, name: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Roll Number"
                                    value={studentRegForm.rollNo}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, rollNo: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Email Address"
                                    type="email"
                                    value={studentRegForm.email}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, email: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Phone Number"
                                    value={studentRegForm.phone}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, phone: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Department"
                                    value={studentRegForm.department}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, department: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Login Username"
                                    value={studentRegForm.username}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, username: e.target.value })}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    required
                                    fullWidth
                                    label="Password (min 6)"
                                    type="password"
                                    value={studentRegForm.password}
                                    onChange={(e) => setStudentRegForm({ ...studentRegForm, password: e.target.value })}
                                />
                            </Grid>
                        </Grid>
                        <Button type="submit" fullWidth variant="contained" color="secondary" sx={{ mt: 4, py: 1.5 }}>
                            Register Account
                        </Button>
                    </Box>
                )}

                {authTab === 2 && (
                    <Box component="form" onSubmit={handleFacultyRegister}>
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            label="Choose Username"
                            value={facultyRegForm.username}
                            onChange={(e) => setFacultyRegForm({ ...facultyRegForm, username: e.target.value })}
                        />
                        <TextField
                            margin="normal"
                            required
                            fullWidth
                            label="Choose Password (min 6)"
                            type="password"
                            value={facultyRegForm.password}
                            onChange={(e) => setFacultyRegForm({ ...facultyRegForm, password: e.target.value })}
                        />
                        <Button type="submit" fullWidth variant="contained" color="primary" sx={{ mt: 4, py: 1.5 }}>
                            Register Faculty Account
                        </Button>
                    </Box>
                )}
            </Paper>
        </Container>
    );

    // Faculty view
    const renderFacultyDashboard = () => (
        <Box className="animate-fade-in">
            {renderAppBar()}

            <Container maxWidth="lg" sx={{ mt: 4, pb: 8 }}>
                <Tabs
                    value={facultyTab}
                    onChange={(e, val) => setFacultyTab(val)}
                    variant="scrollable"
                    scrollButtons="auto"
                    textColor="primary"
                    indicatorColor="primary"
                    sx={{ mb: 4, borderBottom: '1px solid rgba(0, 0, 0, 0.05)' }}
                >
                    <Tab label="Overview" icon={<DashIcon />} iconPosition="start" />
                    <Tab 
                        label="Students Directory" 
                        icon={
                            <Badge badgeContent={tempStudents.length} color="secondary">
                                <People />
                            </Badge>
                        } 
                        iconPosition="start" 
                    />
                    <Tab label="Record Attendance" icon={<AssignmentTurnedIn />} iconPosition="start" />
                    <Tab label="Record Marks" icon={<Grade />} iconPosition="start" />
                    <Tab 
                        label="Attendance Shortages" 
                        icon={
                            <Badge badgeContent={shortageReport.length} color="error">
                                <Warning />
                            </Badge>
                        } 
                        iconPosition="start" 
                    />
                    <Tab label="Academic Reports" icon={<Assessment />} iconPosition="start" />
                </Tabs>

                {loading && <LinearProgress color="primary" sx={{ mb: 3, borderRadius: '4px' }} />}

                {/* 0. Overview */}
                {facultyTab === 0 && (
                    <Fade in={facultyTab === 0} timeout={300}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} sm={4}>
                                <Card className="glass-card-hover" sx={{ bgcolor: 'rgba(255, 255, 255, 0.45)', border: '1px solid rgba(0, 0, 0, 0.05)' }}>
                                    <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2.5, py: 3 }}>
                                        <Avatar sx={{ bgcolor: 'primary.main', width: 52, height: 52, color: '#fff' }}><People /></Avatar>
                                        <Box>
                                            <Typography variant="h4">{students.length}</Typography>
                                            <Typography variant="body2" color="text.secondary">Total Registered Students</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <Card className="glass-card-hover" sx={{ bgcolor: 'rgba(255, 255, 255, 0.45)', border: '1px solid rgba(0, 0, 0, 0.05)' }}>
                                    <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2.5, py: 3 }}>
                                        <Avatar sx={{ bgcolor: 'secondary.main', width: 52, height: 52, color: '#fff' }}><School /></Avatar>
                                        <Box>
                                            <Typography variant="h4">{courses.length}</Typography>
                                            <Typography variant="body2" color="text.secondary">Active Courses</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>
                            <Grid item xs={12} sm={4}>
                                <Card className="glass-card-hover" sx={{ bgcolor: 'rgba(255, 255, 255, 0.45)', border: '1px solid rgba(0, 0, 0, 0.05)' }}>
                                    <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2.5, py: 3 }}>
                                        <Avatar sx={{ bgcolor: shortageReport.length > 0 ? 'error.main' : 'secondary.main', width: 52, height: 52, color: '#fff' }}>
                                            <Warning />
                                        </Avatar>
                                        <Box>
                                            <Typography variant="h4">{shortageReport.length}</Typography>
                                            <Typography variant="body2" color="text.secondary">Attendance Shortage Alerts</Typography>
                                        </Box>
                                    </CardContent>
                                </Card>
                            </Grid>

                            <Grid item xs={12}>
                                <Paper className="glass-panel" sx={{ p: 4, mt: 1, bgcolor: 'rgba(255, 255, 255, 0.7)' }}>
                                    <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Faculty Overview Panel</Typography>
                                    <Typography variant="body2" color="text.secondary" paragraph>
                                        Use this panel to manage courses, verify daily class presence, and compile grades.
                                        You can perform updates for multiple students in a single buffer workflow, modify course catalog listings, and build academic reports.
                                    </Typography>
                                    <Box sx={{ display: 'flex', gap: 2, mt: 3 }}>
                                        <Button variant="contained" color="primary" startIcon={<Add />} onClick={() => {
                                            setStudentForm({ id: null, rollNo: '', name: '', email: '', phone: '', department: '' });
                                            setStudentDialog({ open: true, mode: 'add' });
                                        }}>Add New Student</Button>
                                        <Button variant="outlined" color="primary" startIcon={<School />} onClick={() => setCourseDialog(true)}>Register Course</Button>
                                    </Box>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Fade>
                )}

                {/* 1. Students Directory */}
                {facultyTab === 1 && (
                    <Fade in={facultyTab === 1} timeout={300}>
                        <Box>
                            {/* Search & Actions */}
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, gap: 2 }}>
                                <Box sx={{ display: 'flex', gap: 1, flexGrow: 1, maxWidth: 500 }}>
                                    <TextField
                                        size="small"
                                        placeholder="Search by Roll No or Name..."
                                        value={searchQuery}
                                        onChange={(e) => setSearchQuery(e.target.value)}
                                        sx={{ width: '100%', bgcolor: 'rgba(255,255,255,0.7)', borderRadius: '8px' }}
                                    />
                                    <Button variant="contained" onClick={handleSearch} startIcon={<Search />}>Search</Button>
                                </Box>
                                <Button variant="contained" startIcon={<Add />} onClick={() => {
                                    setStudentForm({ id: null, rollNo: '', name: '', email: '', phone: '', department: '' });
                                    setStudentDialog({ open: true, mode: 'add' });
                                }}>Add Student</Button>
                            </Box>

                            <TableContainer component={Paper} className="glass-panel" sx={{ mb: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Roll No</TableCell>
                                            <TableCell>Name</TableCell>
                                            <TableCell>Email</TableCell>
                                            <TableCell>Phone</TableCell>
                                            <TableCell>Department</TableCell>
                                            <TableCell align="center">Actions</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {students.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={6} align="center" sx={{ py: 4, color: 'text.secondary' }}>No students registered yet.</TableCell>
                                            </TableRow>
                                        ) : (
                                            students.map((s) => (
                                                <TableRow key={s.id} hover>
                                                    <TableCell>{s.rollNo}</TableCell>
                                                    <TableCell>{s.name}</TableCell>
                                                    <TableCell>{s.email}</TableCell>
                                                    <TableCell>{s.phone}</TableCell>
                                                    <TableCell>{s.department}</TableCell>
                                                    <TableCell align="center">
                                                        <Tooltip title="Edit Profile">
                                                            <IconButton color="primary" onClick={() => {
                                                                setStudentForm(s);
                                                                setStudentDialog({ open: true, mode: 'edit' });
                                                            }}><Edit /></IconButton>
                                                        </Tooltip>
                                                        <Tooltip title="Delete Profile">
                                                            <IconButton color="error" onClick={() => handleDeleteStudent(s.rollNo)}><Delete /></IconButton>
                                                        </Tooltip>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>

                            {/* Collections Temporary Registry Buffer in an Accordion to keep UI simpler */}
                            <Accordion sx={{ border: '1px solid rgba(0,0,0,0.05)', bgcolor: 'rgba(255, 255, 255, 0.75)', borderRadius: '16px !important', boxShadow: '0 4px 20px 0 rgba(0,0,0,0.015)' }}>
                                <AccordionSummary expandIcon={<ExpandMore />}>
                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                                        <Badge badgeContent={tempStudents.length} color="secondary">
                                            <People color="secondary" />
                                        </Badge>
                                        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                                            In-Memory Temporary Student Registry Buffer (Collections)
                                        </Typography>
                                    </Box>
                                </AccordionSummary>
                                <AccordionDetails sx={{ px: 3, pb: 4 }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3, flexWrap: 'wrap', gap: 2 }}>
                                        <Typography variant="body2" color="text.secondary">
                                            These records are currently cached in the backend memory buffer. You can commit them in a single batch to the database.
                                        </Typography>
                                        <Box sx={{ display: 'flex', gap: 1.5 }}>
                                            <Button variant="contained" color="secondary" startIcon={<PersonAdd />} onClick={() => {
                                                setStudentForm({ id: null, rollNo: '', name: '', email: '', phone: '', department: '' });
                                                setStudentDialog({ open: true, mode: 'temp' });
                                            }}>Add to Buffer</Button>
                                            <Button variant="contained" color="success" startIcon={<CloudUpload />} onClick={handleCommitTempStudents} disabled={tempStudents.length === 0}>
                                                Commit Buffer
                                            </Button>
                                            <Button variant="outlined" color="error" startIcon={<Delete />} onClick={handleClearTempStudents} disabled={tempStudents.length === 0}>
                                                Clear Buffer
                                            </Button>
                                        </Box>
                                    </Box>

                                    <TableContainer>
                                        <Table size="small">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell>Roll No</TableCell>
                                                    <TableCell>Name</TableCell>
                                                    <TableCell>Email</TableCell>
                                                    <TableCell>Phone</TableCell>
                                                    <TableCell>Department</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {tempStudents.length === 0 ? (
                                                    <TableRow>
                                                        <TableCell colSpan={5} align="center" sx={{ py: 3, color: 'text.secondary' }}>Temporary buffer is empty.</TableCell>
                                                    </TableRow>
                                                ) : (
                                                    tempStudents.map((s, idx) => (
                                                        <TableRow key={idx}>
                                                            <TableCell>{s.rollNo}</TableCell>
                                                            <TableCell>{s.name}</TableCell>
                                                            <TableCell>{s.email}</TableCell>
                                                            <TableCell>{s.phone}</TableCell>
                                                            <TableCell>{s.department}</TableCell>
                                                        </TableRow>
                                                    ))
                                                )}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </AccordionDetails>
                            </Accordion>
                        </Box>
                    </Fade>
                )}

                {/* 2. Record Attendance */}
                {facultyTab === 2 && (
                    <Fade in={facultyTab === 2} timeout={300}>
                        <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Record Daily Class Attendance</Typography>
                            <Grid container spacing={3} sx={{ mb: 4, mt: 0.5 }}>
                                <Grid item xs={12} sm={6}>
                                    <FormControl fullWidth>
                                        <InputLabel>Select Course</InputLabel>
                                        <Select
                                            value={selectedCourse}
                                            label="Select Course"
                                            onChange={(e) => setSelectedCourse(e.target.value)}
                                        >
                                            {courses.map(c => (
                                                <MenuItem key={c.id} value={c.id}>[{c.courseCode}] {c.courseName}</MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12} sm={6}>
                                    <TextField
                                        fullWidth
                                        type="date"
                                        label="Attendance Date"
                                        InputLabelProps={{ shrink: true }}
                                        value={selectedDate}
                                        onChange={(e) => setSelectedDate(e.target.value)}
                                    />
                                </Grid>
                            </Grid>

                            <Typography variant="body1" sx={{ mb: 2, fontWeight: 600 }}>Mark student presence status:</Typography>
                            <TableContainer component={Paper} sx={{ border: '1px solid rgba(0,0,0,0.05)', mb: 3 }}>
                                <Table size="small">
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Roll No</TableCell>
                                            <TableCell>Name</TableCell>
                                            <TableCell align="center">Status Toggle</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {students.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={3} align="center" sx={{ py: 3, color: 'text.secondary' }}>No student records registered.</TableCell>
                                            </TableRow>
                                        ) : (
                                            students.map(s => (
                                                <TableRow key={s.id} hover>
                                                    <TableCell>{s.rollNo}</TableCell>
                                                    <TableCell>{s.name}</TableCell>
                                                    <TableCell align="center">
                                                        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 1.5, py: 0.5 }}>
                                                            <Button
                                                                variant={attendanceMap[s.id] === 'PRESENT' ? 'contained' : 'outlined'}
                                                                color="success"
                                                                size="small"
                                                                onClick={() => setAttendanceMap({ ...attendanceMap, [s.id]: 'PRESENT' })}
                                                            >Present</Button>
                                                            <Button
                                                                variant={attendanceMap[s.id] === 'ABSENT' ? 'contained' : 'outlined'}
                                                                color="error"
                                                                size="small"
                                                                onClick={() => setAttendanceMap({ ...attendanceMap, [s.id]: 'ABSENT' })}
                                                            >Absent</Button>
                                                        </Box>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>

                            <Button variant="contained" color="primary" size="large" onClick={handleMarkAttendanceBatch} disabled={students.length === 0}>
                                Submit Daily Batch Attendance
                            </Button>
                        </Paper>
                    </Fade>
                )}

                {/* 3. Record Marks */}
                {facultyTab === 3 && (
                    <Fade in={facultyTab === 3} timeout={300}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={5}>
                                <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }} component="form" onSubmit={handleRecordMarks}>
                                    <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Enter Exam/Assignment Marks</Typography>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, mt: 3 }}>
                                        <FormControl fullWidth>
                                            <InputLabel>Select Student</InputLabel>
                                            <Select
                                                required
                                                value={marksForm.studentId}
                                                label="Select Student"
                                                onChange={(e) => setMarksForm({ ...marksForm, studentId: e.target.value })}
                                            >
                                                {students.map(s => (
                                                    <MenuItem key={s.id} value={s.id}>{s.name} ({s.rollNo})</MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>

                                        <FormControl fullWidth>
                                            <InputLabel>Select Course</InputLabel>
                                            <Select
                                                required
                                                value={marksForm.courseId}
                                                label="Select Course"
                                                onChange={(e) => setMarksForm({ ...marksForm, courseId: e.target.value })}
                                            >
                                                {courses.map(c => (
                                                    <MenuItem key={c.id} value={c.id}>[{c.courseCode}] {c.courseName}</MenuItem>
                                                ))}
                                            </Select>
                                        </FormControl>

                                        <FormControl fullWidth>
                                            <InputLabel>Select Assessment Type</InputLabel>
                                            <Select
                                                value={marksForm.examType}
                                                label="Select Assessment Type"
                                                onChange={(e) => setMarksForm({ ...marksForm, examType: e.target.value })}
                                            >
                                                <MenuItem value="MST_1">MST 1</MenuItem>
                                                <MenuItem value="MST_2">MST 2</MenuItem>
                                                <MenuItem value="ASSIGNMENT_1">Assignment 1</MenuItem>
                                                <MenuItem value="ASSIGNMENT_2">Assignment 2</MenuItem>
                                            </Select>
                                        </FormControl>

                                        <TextField
                                            required
                                            label="Max Marks Possible"
                                            type="number"
                                            value={marksForm.maxMarks}
                                            onChange={(e) => setMarksForm({ ...marksForm, maxMarks: e.target.value })}
                                        />

                                        <TextField
                                            required
                                            label="Marks Obtained"
                                            type="number"
                                            value={marksForm.marksObtained}
                                            onChange={(e) => setMarksForm({ ...marksForm, marksObtained: e.target.value })}
                                        />

                                        <Button type="submit" variant="contained" color="secondary" size="large">Submit Marks</Button>
                                    </Box>
                                </Paper>
                            </Grid>
                            
                            <Grid item xs={12} md={7}>
                                <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                                    <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Recent Grades Sheet Logs</Typography>
                                    <Typography variant="body2" color="text.secondary" paragraph>
                                        Select a student from directory or generate reports to view full logs history.
                                    </Typography>
                                    <TableContainer sx={{ mt: 2 }}>
                                        <Table size="small">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell>Student</TableCell>
                                                    <TableCell>Course</TableCell>
                                                    <TableCell>Type</TableCell>
                                                    <TableCell>Marks</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                <TableRow>
                                                    <TableCell colSpan={4} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                                                        Query performance report under Academic Reports tab to compile complete grade charts.
                                                    </TableCell>
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Fade>
                )}

                {/* 4. Shortages */}
                {facultyTab === 4 && (
                    <Fade in={facultyTab === 4} timeout={300}>
                        <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Attendance Shortage Alerts (&lt;75%)</Typography>
                            <Typography variant="body2" color="text.secondary" paragraph>
                                The following students do not meet the minimum academic criteria of **75.0% attendance** across active classes.
                            </Typography>

                            <TableContainer component={Paper} sx={{ mt: 3, border: '1px solid rgba(0,0,0,0.05)' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Roll No</TableCell>
                                            <TableCell>Student Name</TableCell>
                                            <TableCell>Email</TableCell>
                                            <TableCell>Phone</TableCell>
                                            <TableCell align="center">Overall Attendance %</TableCell>
                                            <TableCell align="center">Status</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {shortageReport.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={6} align="center" sx={{ py: 4, color: 'text.secondary' }}>No attendance shortage alerts currently active.</TableCell>
                                            </TableRow>
                                        ) : (
                                            shortageReport.map((row, idx) => (
                                                <TableRow key={idx} hover>
                                                    <TableCell>{row.student.rollNo}</TableCell>
                                                    <TableCell>{row.student.name}</TableCell>
                                                    <TableCell>{row.student.email}</TableCell>
                                                    <TableCell>{row.student.phone}</TableCell>
                                                    <TableCell align="center">
                                                        <b style={{ color: '#e11d48' }}>{row.percentage.toFixed(2)}%</b>
                                                    </TableCell>
                                                    <TableCell align="center">
                                                        <Chip label="Shortage Alert" color="error" size="small" icon={<Warning />} />
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Fade>
                )}

                {/* 5. Academic Reports */}
                {facultyTab === 5 && (
                    <Fade in={facultyTab === 5} timeout={300}>
                        <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Generate Student Performance Report Card</Typography>
                            <Box sx={{ display: 'flex', gap: 2, mt: 3, mb: 4, maxWidth: 500 }}>
                                <TextField
                                    fullWidth
                                    label="Search Student Roll Number"
                                    value={reportSearchRoll}
                                    onChange={(e) => setReportSearchRoll(e.target.value)}
                                />
                                <Button variant="contained" color="primary" onClick={handleSearchReport} startIcon={<Search />}>Generate</Button>
                            </Box>

                            {generatedReport && (
                                <Box className="animate-fade-in" id="printable-report">
                                    <Divider sx={{ my: 3 }} />
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
                                        <Box>
                                            <Typography variant="h5" color="primary" sx={{ fontWeight: 800 }}>REPORT CARD</Typography>
                                            <Typography variant="body1" sx={{ mt: 1 }}>Name: <b>{generatedReport.student.name}</b></Typography>
                                            <Typography variant="body2" color="text.secondary">Roll No: {generatedReport.student.rollNo}</Typography>
                                            <Typography variant="body2" color="text.secondary">Dept: {generatedReport.student.department}</Typography>
                                        </Box>
                                        <Box sx={{ textAlign: 'right' }}>
                                            <Typography variant="h4" color="secondary" sx={{ fontWeight: 800 }}>{generatedReport.cgpa.toFixed(2)}</Typography>
                                            <Typography variant="caption" color="text.secondary">CGPA Score (10.0)</Typography>
                                            <Box sx={{ mt: 1 }}>
                                                <Chip
                                                    label={generatedReport.hasOverallShortage ? 'Attendance Warning' : 'Attendance Safe'}
                                                    color={generatedReport.hasOverallShortage ? 'error' : 'success'}
                                                    size="small"
                                                />
                                            </Box>
                                        </Box>
                                    </Box>

                                    <Typography variant="h6" gutterBottom sx={{ mt: 4, fontWeight: 700 }}>Course-wise Breakdowns</Typography>
                                    <TableContainer component={Paper} sx={{ border: '1px solid rgba(0,0,0,0.05)' }}>
                                        <Table>
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell>Course</TableCell>
                                                    <TableCell align="center">Classes (Present/Total)</TableCell>
                                                    <TableCell align="center">Attendance %</TableCell>
                                                    <TableCell align="center">Average Grade</TableCell>
                                                    <TableCell>MST/Assignment Scores Summary</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {generatedReport.courseSummaries.map((summary, idx) => (
                                                    <TableRow key={idx}>
                                                        <TableCell>
                                                            <b>{summary.course.courseName}</b><br />
                                                            <Typography variant="caption" color="text.secondary">{summary.course.courseCode}</Typography>
                                                        </TableCell>
                                                        <TableCell align="center">{summary.presentClasses} / {summary.totalClasses}</TableCell>
                                                        <TableCell align="center">
                                                            <span style={{ color: summary.hasShortage ? '#e11d48' : '#0d9488', fontWeight: 700 }}>
                                                                {summary.attendancePercentage.toFixed(2)}%
                                                            </span>
                                                        </TableCell>
                                                        <TableCell align="center">
                                                            <b>{summary.averageGradePercentage.toFixed(2)}%</b>
                                                        </TableCell>
                                                        <TableCell>
                                                            {summary.marksHistory.length === 0 ? (
                                                                <Typography variant="caption" color="text.secondary">No scores recorded</Typography>
                                                            ) : (
                                                                summary.marksHistory.map((m, mIdx) => (
                                                                    <Chip 
                                                                        key={mIdx} 
                                                                        label={`${m.examType}: ${m.marksObtained}/${m.maxMarks}`} 
                                                                        size="small" 
                                                                        variant="outlined" 
                                                                        sx={{ mr: 0.5, mb: 0.5, fontWeight: 600 }} 
                                                                    />
                                                                ))
                                                            )}
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Box>
                            )}
                        </Paper>
                    </Fade>
                )}
            </Container>
        </Box>
    );

    // Student view
    const renderStudentDashboard = () => (
        <Box className="animate-fade-in">
            {renderAppBar()}

            <Container maxWidth="lg" sx={{ mt: 4, pb: 8 }}>
                <Tabs
                    value={studentTab}
                    onChange={(e, val) => setStudentTab(val)}
                    textColor="primary"
                    indicatorColor="primary"
                    sx={{ mb: 4, borderBottom: '1px solid rgba(0, 0, 0, 0.05)' }}
                >
                    <Tab label="My Profile" icon={<AssignmentInd />} iconPosition="start" />
                    <Tab label="My Attendance" icon={<AssignmentTurnedIn />} iconPosition="start" />
                    <Tab label="My Grades Sheet" icon={<Grade />} iconPosition="start" />
                    <Tab label="My Academic Report" icon={<Assessment />} iconPosition="start" />
                </Tabs>

                {loading && <LinearProgress color="primary" sx={{ mb: 3, borderRadius: '4px' }} />}

                {/* 0. Student Profile */}
                {studentTab === 0 && myProfile && (
                    <Fade in={studentTab === 0} timeout={300}>
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={4}>
                                <Card className="glass-card-hover" sx={{ textAlign: 'center', p: 4, bgcolor: 'rgba(255, 255, 255, 0.45)', border: '1px solid rgba(0,0,0,0.05)' }}>
                                    <Avatar sx={{ width: 80, height: 80, mx: 'auto', mb: 2, bgcolor: 'primary.main', fontSize: '2rem', fontWeight: 800, color: '#fff' }}>
                                        {myProfile.name.charAt(0)}
                                    </Avatar>
                                    <Typography variant="h5" sx={{ mt: 1, fontWeight: 700 }}>{myProfile.name}</Typography>
                                    <Typography variant="body2" color="text.secondary">{myProfile.rollNo}</Typography>
                                    <Chip label={myProfile.department} color="primary" variant="outlined" sx={{ mt: 3, fontWeight: 700 }} />
                                </Card>
                            </Grid>
                            <Grid item xs={12} md={8}>
                                <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                                    <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Profile Details</Typography>
                                    <Divider sx={{ my: 2 }} />
                                    <Grid container spacing={3} sx={{ mt: 0.5 }}>
                                        <Grid item xs={12} sm={6}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                                <Avatar sx={{ bgcolor: 'rgba(79, 70, 229, 0.08)', color: 'primary.main' }}>
                                                    <Email />
                                                </Avatar>
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary">Email Address</Typography>
                                                    <Typography variant="body1" sx={{ fontWeight: 600 }}>{myProfile.email}</Typography>
                                                </Box>
                                            </Box>
                                        </Grid>
                                        <Grid item xs={12} sm={6}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                                <Avatar sx={{ bgcolor: 'rgba(13, 148, 136, 0.08)', color: 'secondary.main' }}>
                                                    <Phone />
                                                </Avatar>
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary">Phone Number</Typography>
                                                    <Typography variant="body1" sx={{ fontWeight: 600 }}>{myProfile.phone}</Typography>
                                                </Box>
                                            </Box>
                                        </Grid>
                                        <Grid item xs={12} sm={6}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                                <Avatar sx={{ bgcolor: 'rgba(217, 119, 6, 0.08)', color: 'warning.main' }}>
                                                    <School />
                                                </Avatar>
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary">Department</Typography>
                                                    <Typography variant="body1" sx={{ fontWeight: 600 }}>{myProfile.department}</Typography>
                                                </Box>
                                            </Box>
                                        </Grid>
                                        <Grid item xs={12} sm={6}>
                                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                                <Avatar sx={{ bgcolor: 'rgba(79, 70, 229, 0.08)', color: 'primary.main' }}>
                                                    <AssignmentInd />
                                                </Avatar>
                                                <Box>
                                                    <Typography variant="caption" color="text.secondary">System Profile ID</Typography>
                                                    <Typography variant="body1" sx={{ fontWeight: 600 }}>STUD-{myProfile.id}</Typography>
                                                </Box>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Fade>
                )}

                {/* 1. Student Attendance */}
                {studentTab === 1 && myReport && (
                    <Fade in={studentTab === 1} timeout={300}>
                        <Box>
                            {myReport.hasOverallShortage && (
                                <Alert severity="error" sx={{ mb: 4, borderRadius: '8px' }} icon={<Warning />}>
                                    <b>Attendance Warning:</b> Your overall attendance percentage is below the minimum required 75.0%. Please contact your faculty members.
                                </Alert>
                            )}
                            <Grid container spacing={3}>
                                {myReport.courseSummaries.map((summary, idx) => (
                                    <Grid item xs={12} sm={6} md={3} key={idx}>
                                        <Card className="glass-card-hover" sx={{ p: 3, textAlign: 'center', bgcolor: 'rgba(255, 255, 255, 0.45)', border: '1px solid rgba(0,0,0,0.05)' }}>
                                            <Typography variant="body1" sx={{ fontWeight: 700 }}>{summary.course.courseName}</Typography>
                                            <Typography variant="caption" color="text.secondary">{summary.course.courseCode}</Typography>
                                            <Box sx={{ position: 'relative', display: 'inline-flex', my: 3 }}>
                                                <CircularProgress
                                                    variant="determinate"
                                                    value={summary.attendancePercentage}
                                                    size={80}
                                                    thickness={6}
                                                    color={summary.hasShortage ? 'error' : 'secondary'}
                                                />
                                                <Box
                                                    sx={{
                                                        top: 0, left: 0, bottom: 0, right: 0,
                                                        position: 'absolute', display: 'flex',
                                                        alignItems: 'center', justifyContent: 'center',
                                                    }}
                                                >
                                                    <Typography variant="caption" component="div" color="text.primary" fontWeight={800}>
                                                        {summary.attendancePercentage.toFixed(0)}%
                                                    </Typography>
                                                </Box>
                                            </Box>
                                            <Typography variant="body2" color="text.secondary">
                                                Present: <b>{summary.presentClasses}</b> / {summary.totalClasses} classes
                                            </Typography>
                                        </Card>
                                    </Grid>
                                ))}
                            </Grid>

                            <Paper className="glass-panel" sx={{ p: 4, mt: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                                <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>Detailed Attendance History Log</Typography>
                                <TableContainer sx={{ mt: 2 }}>
                                    <Table size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Date</TableCell>
                                                <TableCell>Course Code</TableCell>
                                                <TableCell>Course Name</TableCell>
                                                <TableCell>Status</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {myAttendance.length === 0 ? (
                                                <TableRow>
                                                    <TableCell colSpan={4} align="center" sx={{ py: 3, color: 'text.secondary' }}>No attendance logs found.</TableCell>
                                                </TableRow>
                                            ) : (
                                                myAttendance.map((att, idx) => (
                                                    <TableRow key={idx} hover>
                                                        <TableCell>{att.date}</TableCell>
                                                        <TableCell>{getCourseCode(att.courseId)}</TableCell>
                                                        <TableCell>{getCourseName(att.courseId)}</TableCell>
                                                        <TableCell>
                                                            <Chip 
                                                                label={att.status} 
                                                                color={att.status === 'PRESENT' ? 'success' : 'error'} 
                                                                size="small" 
                                                                sx={{ fontWeight: 800 }}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                ))
                                            )}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Box>
                    </Fade>
                )}

                {/* 2. Student Grades */}
                {studentTab === 2 && (
                    <Fade in={studentTab === 2} timeout={300}>
                        <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700 }}>My Academic Scores & Grades</Typography>
                            <TableContainer sx={{ mt: 3, border: '1px solid rgba(0, 0, 0, 0.05)' }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Course Code</TableCell>
                                            <TableCell>Course Name</TableCell>
                                            <TableCell>Assessment Type</TableCell>
                                            <TableCell>Marks Scored</TableCell>
                                            <TableCell>Percentage Grade</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {myMarks.length === 0 ? (
                                            <TableRow>
                                                <TableCell colSpan={5} align="center" sx={{ py: 4, color: 'text.secondary' }}>No marks recorded yet.</TableCell>
                                            </TableRow>
                                        ) : (
                                            myMarks.map((m, idx) => (
                                                <TableRow key={idx} hover>
                                                    <TableCell>{getCourseCode(m.courseId)}</TableCell>
                                                    <TableCell><b>{getCourseName(m.courseId)}</b></TableCell>
                                                    <TableCell>{m.examType}</TableCell>
                                                    <TableCell>{m.marksObtained} / {m.maxMarks}</TableCell>
                                                    <TableCell>
                                                        <b>{((m.marksObtained / m.maxMarks) * 100).toFixed(2)}%</b>
                                                    </TableCell>
                                                </TableRow>
                                            ))
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Fade>
                )}

                {/* 3. Student Report Card */}
                {studentTab === 3 && myReport && (
                    <Fade in={studentTab === 3} timeout={300}>
                        <Paper className="glass-panel" sx={{ p: 4, bgcolor: 'rgba(255, 255, 255, 0.75)' }}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                                <Typography variant="h6" sx={{ fontWeight: 700 }}>Academic Report Card</Typography>
                                <Button variant="outlined" startIcon={<FileDownload />} onClick={() => window.print()}>Print Report Card</Button>
                            </Box>
                            
                            <Divider sx={{ my: 3 }} />
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
                                <Box>
                                    <Typography variant="h5" color="primary" sx={{ fontWeight: 800 }}>PERFORMANCE SUMMARY</Typography>
                                    <Typography variant="body1" sx={{ mt: 1 }}>Name: <b>{myReport.student.name}</b></Typography>
                                    <Typography variant="body2" color="text.secondary">Roll No: {myReport.student.rollNo}</Typography>
                                    <Typography variant="body2" color="text.secondary">Dept: {myReport.student.department}</Typography>
                                </Box>
                                <Box sx={{ textAlign: 'right' }}>
                                    <Typography variant="h4" color="secondary" sx={{ fontWeight: 800 }}>{myReport.cgpa.toFixed(2)}</Typography>
                                    <Typography variant="caption" color="text.secondary">CGPA Score (10.0)</Typography>
                                    <Box sx={{ mt: 1 }}>
                                        <Chip
                                            label={myReport.hasOverallShortage ? 'Attendance Alert' : 'Attendance Clear'}
                                            color={myReport.hasOverallShortage ? 'error' : 'success'}
                                            size="small"
                                        />
                                    </Box>
                                </Box>
                            </Box>

                            <TableContainer component={Paper} sx={{ border: '1px solid rgba(0, 0, 0, 0.05)', mt: 4 }}>
                                <Table>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Course Code</TableCell>
                                            <TableCell>Course Name</TableCell>
                                            <TableCell align="center">Attendance Percentage</TableCell>
                                            <TableCell align="center">Average Marks</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {myReport.courseSummaries.map((summary, idx) => (
                                            <TableRow key={idx}>
                                                <TableCell>{summary.course.courseCode}</TableCell>
                                                <TableCell><b>{summary.course.courseName}</b></TableCell>
                                                <TableCell align="center" style={{ color: summary.hasShortage ? '#e11d48' : '#0d9488', fontWeight: 700 }}>
                                                    {summary.attendancePercentage.toFixed(2)}%
                                                </TableCell>
                                                <TableCell align="center">
                                                    <b>{summary.averageGradePercentage.toFixed(2)}%</b>
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Fade>
                )}
            </Container>
        </Box>
    );

    return (
        <ThemeProvider theme={theme}>
            <CssBaseline />
            
            {view === 'auth' ? renderAuthScreen() : (user.role === 'FACULTY' ? renderFacultyDashboard() : renderStudentDashboard())}

            {/* Notification Alert Snackbar */}
            <Snackbar open={notification.open} autoHideDuration={4000} onClose={handleNotificationClose}>
                <Alert onClose={handleNotificationClose} severity={notification.severity} sx={{ width: '100%' }}>
                    {notification.message}
                </Alert>
            </Snackbar>

            {/* Student Add/Edit Modal */}
            <Dialog open={studentDialog.open} onClose={() => setStudentDialog({ ...studentDialog, open: false })}>
                <DialogTitle sx={{ fontWeight: 700 }}>
                    {studentDialog.mode === 'add' ? 'Add Student Profile' : (studentDialog.mode === 'temp' ? 'Add Student to Collections Buffer' : 'Update Student Details')}
                </DialogTitle>
                <DialogContent>
                    <Box component="form" sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mt: 2.5, minWidth: 320 }}>
                        <TextField
                            required
                            label="Roll Number"
                            disabled={studentDialog.mode === 'edit'}
                            value={studentForm.rollNo}
                            onChange={(e) => setStudentForm({ ...studentForm, rollNo: e.target.value })}
                        />
                        <TextField
                            required
                            label="Full Name"
                            value={studentForm.name}
                            onChange={(e) => setStudentForm({ ...studentForm, name: e.target.value })}
                        />
                        <TextField
                            required
                            label="Email Address"
                            type="email"
                            value={studentForm.email}
                            onChange={(e) => setStudentForm({ ...studentForm, email: e.target.value })}
                        />
                        <TextField
                            required
                            label="Phone Number"
                            value={studentForm.phone}
                            onChange={(e) => setStudentForm({ ...studentForm, phone: e.target.value })}
                        />
                        <TextField
                            required
                            label="Department"
                            value={studentForm.department}
                            onChange={(e) => setStudentForm({ ...studentForm, department: e.target.value })}
                        />
                    </Box>
                </DialogContent>
                <DialogActions sx={{ p: 2.5 }}>
                    <Button onClick={() => setStudentDialog({ ...studentDialog, open: false })}>Cancel</Button>
                    {studentDialog.mode === 'temp' ? (
                        <Button variant="contained" color="secondary" onClick={handleAddStudentTemp}>Add to Buffer</Button>
                    ) : (
                        <Button variant="contained" color="primary" onClick={handleAddOrEditStudent}>Save Profile</Button>
                    )}
                </DialogActions>
            </Dialog>

            {/* Course Add Modal */}
            <Dialog open={courseDialog} onClose={() => setCourseDialog(false)}>
                <DialogTitle sx={{ fontWeight: 700 }}>Add Course Profile</DialogTitle>
                <DialogContent component="form" onSubmit={handleAddCourse}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mt: 2.5, minWidth: 320 }}>
                        <TextField
                            required
                            label="Course Code"
                            placeholder="e.g. CS105"
                            value={courseForm.courseCode}
                            onChange={(e) => setCourseForm({ ...courseForm, courseCode: e.target.value })}
                        />
                        <TextField
                            required
                            label="Course Name"
                            placeholder="e.g. Artificial Intelligence"
                            value={courseForm.courseName}
                            onChange={(e) => setCourseForm({ ...courseForm, courseName: e.target.value })}
                        />
                    </Box>
                </DialogContent>
                <DialogActions sx={{ p: 2.5 }}>
                    <Button onClick={() => setCourseDialog(false)}>Cancel</Button>
                    <Button variant="contained" color="primary" onClick={handleAddCourse}>Create Course</Button>
                </DialogActions>
            </Dialog>
        </ThemeProvider>
    );
}

export default App;
