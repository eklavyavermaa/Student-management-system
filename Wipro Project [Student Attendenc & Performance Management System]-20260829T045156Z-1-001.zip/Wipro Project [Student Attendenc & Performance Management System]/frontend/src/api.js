import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

export const authAPI = {
    login: (username, password) => api.post('/auth/login', { username, password }),
    registerStudent: (data) => api.post('/auth/register-student', data),
    registerFaculty: (username, password) => api.post('/auth/register-faculty', { username, password }),
};

export const studentAPI = {
    getAll: () => api.get('/students'),
    search: (query) => api.get(`/students/search?query=${encodeURIComponent(query)}`),
    getById: (id) => api.get(`/students/id/${id}`),
    getByRoll: (rollNo) => api.get(`/students/roll/${rollNo}`),
    add: (student) => api.post('/students', student),
    update: (student) => api.put('/students', student),
    delete: (rollNo) => api.delete(`/students/${rollNo}`),
    
    getTemp: () => api.get('/students/temp'),
    addTemp: (student) => api.post('/students/temp', student),
    commitTemp: () => api.post('/students/temp/commit'),
    clearTemp: () => api.delete('/students/temp/clear'),
};

export const courseAPI = {
    getAll: () => api.get('/courses'),
    add: (course) => api.post('/courses', course),
};

export const attendanceAPI = {
    getHistory: (studentId) => api.get(`/attendance/student/${studentId}`),
    mark: (studentId, courseId, date, status) => api.post('/attendance/mark', { studentId, courseId, date, status }),
    markBatch: (courseId, date, studentStatusMap) => api.post('/attendance/mark-batch', { courseId, date, studentStatusMap }),
    getShortageReport: () => api.get('/attendance/shortage-report'),
};

export const marksAPI = {
    getHistory: (studentId) => api.get(`/marks/student/${studentId}`),
    record: (studentId, courseId, examType, marksObtained, maxMarks) => 
        api.post('/marks/record', { studentId, courseId, examType, marksObtained, maxMarks }),
};

export const reportAPI = {
    generate: (rollNo) => api.get(`/reports/student/${rollNo}`),
};

export default api;
