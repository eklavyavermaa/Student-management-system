package com.management.student.service;

import com.management.student.dao.StudentDAO;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class StudentServiceTest {

    @Mock
    private StudentDAO studentDAO;

    private StudentService studentService;

    @BeforeEach
    public void setUp() {
        studentService = new StudentService(studentDAO);
    }

    @Test
    public void testValidateStudent_ValidDetails() throws Exception {
        Student student = new Student("John Doe", "john.doe@example.com", "9876543210", "S101", "CSE");
        // Should compile/execute without exceptions
        studentService.validateStudent(student);
    }

    @Test
    public void testValidateStudent_InvalidEmail() {
        Student student = new Student("John Doe", "invalid-email", "9876543210", "S101", "CSE");
        assertThrows(InvalidDataException.class, () -> {
            studentService.validateStudent(student);
        });
    }

    @Test
    public void testValidateStudent_InvalidPhone() {
        Student student = new Student("John Doe", "john@example.com", "123", "S101", "CSE");
        assertThrows(InvalidDataException.class, () -> {
            studentService.validateStudent(student);
        });
    }

    @Test
    public void testValidateStudent_EmptyRollNo() {
        Student student = new Student("John Doe", "john@example.com", "9876543210", "  ", "CSE");
        assertThrows(InvalidDataException.class, () -> {
            studentService.validateStudent(student);
        });
    }

    @Test
    public void testTemporaryBufferCollections() throws Exception {
        studentService.clearTemporaryStudents();
        assertTrue(studentService.getTemporaryStudents().isEmpty());

        Student s1 = new Student("Alice", "alice@example.com", "9876543210", "S201", "ECE");
        Student s2 = new Student("Bob", "bob@example.com", "9876543211", "S202", "CSE");

        // Mock DAO behaviour so it does not connect to database
        when(studentDAO.findByRollNo("S201")).thenReturn(null);
        when(studentDAO.findByRollNo("S202")).thenReturn(null);

        studentService.addTemporaryStudent(s1);
        studentService.addTemporaryStudent(s2);

        assertEquals(2, studentService.getTemporaryStudents().size());
        assertEquals("S201", studentService.getTemporaryStudents().get(0).getRollNo());

        studentService.clearTemporaryStudents();
        assertTrue(studentService.getTemporaryStudents().isEmpty());
    }
}
