package com.management.student.exception;

/**
 * Thrown when user authentication fails or permissions are denied.
 */
public class AuthenticationException extends StudentManagementException {
    public AuthenticationException(String message) {
        super(message);
    }
}
