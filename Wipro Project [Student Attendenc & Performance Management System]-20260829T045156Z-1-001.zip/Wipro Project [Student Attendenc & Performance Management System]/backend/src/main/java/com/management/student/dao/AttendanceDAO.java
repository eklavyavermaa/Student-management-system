package com.management.student.dao;

import com.management.student.exception.DatabaseException;
import com.management.student.model.Attendance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles database operations for student attendance bound to specific courses.
 */
public class AttendanceDAO {

    public boolean markAttendance(Attendance attendance) throws DatabaseException {
        String sql = "INSERT INTO attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, attendance.getStudentId());
            pstmt.setInt(2, attendance.getCourseId());
            pstmt.setDate(3, Date.valueOf(attendance.getDate()));
            pstmt.setString(4, attendance.getStatus());
            pstmt.setString(5, attendance.getStatus());

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to log attendance for student ID: " + attendance.getStudentId(), e);
        }
    }

    public boolean markAttendanceBatch(List<Attendance> attendanceList) throws DatabaseException {
        String sql = "INSERT INTO attendance (student_id, course_id, date, status) VALUES (?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE status = ?";
        
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);
            
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                for (Attendance att : attendanceList) {
                    pstmt.setInt(1, att.getStudentId());
                    pstmt.setInt(2, att.getCourseId());
                    pstmt.setDate(3, Date.valueOf(att.getDate()));
                    pstmt.setString(4, att.getStatus());
                    pstmt.setString(5, att.getStatus());
                    pstmt.addBatch();
                }
                
                int[] results = pstmt.executeBatch();
                conn.commit();
                
                for (int res : results) {
                    if (res == PreparedStatement.EXECUTE_FAILED) {
                        return false;
                    }
                }
                return true;
            } catch (SQLException e) {
                if (conn != null) {
                    conn.rollback();
                }
                throw e;
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to mark batch attendance", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    System.err.println("[WARN] Failed to close connection cleanly: " + e.getMessage());
                }
            }
        }
    }

    public List<Attendance> getAttendanceHistory(int studentId) throws DatabaseException {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT id, student_id, course_id, date, status FROM attendance WHERE student_id = ? ORDER BY date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Attendance att = new Attendance();
                    att.setId(rs.getInt("id"));
                    att.setStudentId(rs.getInt("student_id"));
                    att.setCourseId(rs.getInt("course_id"));
                    att.setDate(rs.getDate("date").toLocalDate());
                    att.setStatus(rs.getString("status"));
                    list.add(att);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving attendance history for student ID: " + studentId, e);
        }
        return list;
    }

    public List<Attendance> getAttendanceHistoryForCourse(int studentId, int courseId) throws DatabaseException {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT id, student_id, course_id, date, status FROM attendance WHERE student_id = ? AND course_id = ? ORDER BY date DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Attendance att = new Attendance();
                    att.setId(rs.getInt("id"));
                    att.setStudentId(rs.getInt("student_id"));
                    att.setCourseId(rs.getInt("course_id"));
                    att.setDate(rs.getDate("date").toLocalDate());
                    att.setStatus(rs.getString("status"));
                    list.add(att);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving course attendance history", e);
        }
        return list;
    }
}
