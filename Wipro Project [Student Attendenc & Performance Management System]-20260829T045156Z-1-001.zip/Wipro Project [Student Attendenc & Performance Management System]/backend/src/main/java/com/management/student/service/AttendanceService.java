package com.management.student.service;

import com.management.student.dao.AttendanceDAO;
import com.management.student.dao.CourseDAO;
import com.management.student.dao.DBConnection;
import com.management.student.dao.StudentDAO;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Attendance;
import com.management.student.model.Student;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Manages Daily attendance logs, course percentages, and shortage check alerts.
 */
public class AttendanceService {
    private final AttendanceDAO attendanceDAO = new AttendanceDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final CourseDAO courseDAO = new CourseDAO();

    public void markAttendance(int studentId, int courseId, LocalDate date, String status) 
            throws DatabaseException, InvalidDataException {
        
        validateAttendanceDetails(studentId, courseId, date, status);

        Attendance attendance = new Attendance(studentId, courseId, date, status.toUpperCase());
        attendanceDAO.markAttendance(attendance);
    }

    public void markAttendanceBatch(Map<Integer, String> studentStatusMap, int courseId, LocalDate date) 
            throws DatabaseException, InvalidDataException {
        
        if (date == null || date.isAfter(LocalDate.now())) {
            throw new InvalidDataException("Attendance date cannot be in the future.");
        }
        if (studentStatusMap == null || studentStatusMap.isEmpty()) {
            throw new InvalidDataException("Batch record is empty.");
        }

        List<Attendance> batchList = new ArrayList<>();
        for (Map.Entry<Integer, String> entry : studentStatusMap.entrySet()) {
            int studentId = entry.getKey();
            String status = entry.getValue();
            
            validateAttendanceDetails(studentId, courseId, date, status);
            batchList.add(new Attendance(studentId, courseId, date, status.toUpperCase()));
        }

        boolean success = attendanceDAO.markAttendanceBatch(batchList);
        if (!success) {
            throw new DatabaseException("Failed to complete batch update of attendance.");
        }
    }

    private void validateAttendanceDetails(int studentId, int courseId, LocalDate date, String status) 
            throws InvalidDataException, DatabaseException {
        
        if (studentDAO.findById(studentId) == null) {
            throw new InvalidDataException("Student with ID " + studentId + " does not exist.");
        }
        if (courseDAO.findById(courseId) == null) {
            throw new InvalidDataException("Course with ID " + courseId + " does not exist.");
        }
        if (date == null || date.isAfter(LocalDate.now())) {
            throw new InvalidDataException("Attendance date cannot be in the future.");
        }
        if (status == null || (!"PRESENT".equalsIgnoreCase(status) && !"ABSENT".equalsIgnoreCase(status))) {
            throw new InvalidDataException("Invalid attendance status. Must be 'PRESENT' or 'ABSENT'.");
        }
    }

    public double calculateAttendancePercentage(int studentId) throws DatabaseException {
        List<Attendance> history = attendanceDAO.getAttendanceHistory(studentId);
        if (history.isEmpty()) {
            return 100.0; // Standard baseline if no classes conducted yet
        }
        long presentCount = history.stream().filter(a -> "PRESENT".equalsIgnoreCase(a.getStatus())).count();
        return ((double) presentCount / history.size()) * 100.0;
    }

    public double calculateCourseAttendancePercentage(int studentId, int courseId) throws DatabaseException {
        List<Attendance> history = attendanceDAO.getAttendanceHistoryForCourse(studentId, courseId);
        if (history.isEmpty()) {
            return 100.0; // Baseline
        }
        long presentCount = history.stream().filter(a -> "PRESENT".equalsIgnoreCase(a.getStatus())).count();
        return ((double) presentCount / history.size()) * 100.0;
    }

    public boolean hasShortage(int studentId) throws DatabaseException {
        double percentage = calculateAttendancePercentage(studentId);
        return percentage < DBConnection.getAttendanceThreshold();
    }

    public boolean hasCourseShortage(int studentId, int courseId) throws DatabaseException {
        List<Attendance> history = attendanceDAO.getAttendanceHistoryForCourse(studentId, courseId);
        if (history.isEmpty()) {
            return false;
        }
        double percentage = calculateCourseAttendancePercentage(studentId, courseId);
        return percentage < DBConnection.getAttendanceThreshold();
    }

    /**
     * Map of students experiencing overall shortage alerts.
     */
    public Map<Student, Double> getAttendanceShortageReport() throws DatabaseException {
        Map<Student, Double> shortageMap = new HashMap<>();
        List<Student> students = studentDAO.getAllStudents();
        double threshold = DBConnection.getAttendanceThreshold();

        for (Student s : students) {
            List<Attendance> history = attendanceDAO.getAttendanceHistory(s.getId());
            if (!history.isEmpty()) {
                double pct = calculateAttendancePercentage(s.getId());
                if (pct < threshold) {
                    shortageMap.put(s, pct);
                }
            }
        }
        return shortageMap;
    }

    public List<Attendance> getAttendanceHistory(int studentId) throws DatabaseException {
        return attendanceDAO.getAttendanceHistory(studentId);
    }

    public List<Attendance> getAttendanceHistoryForCourse(int studentId, int courseId) throws DatabaseException {
        return attendanceDAO.getAttendanceHistoryForCourse(studentId, courseId);
    }
}
