package com.management.student.exception;

/**
 * Thrown when data validation checks fail (e.g., invalid marks, email format, or numbers).
 */
public class InvalidDataException extends StudentManagementException {
    public InvalidDataException(String message) {
        super(message);
    }
}
