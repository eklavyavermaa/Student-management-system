package com.management.student.service;

import com.management.student.dao.UserDAO;
import com.management.student.exception.AuthenticationException;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.User;

/**
 * Service providing user registration and login business rules.
 */
public class UserService {
    private final UserDAO userDAO = new UserDAO();

    public User login(String username, String password) throws DatabaseException, AuthenticationException {
        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            throw new AuthenticationException("Username and Password cannot be blank.");
        }
        User user = userDAO.authenticate(username.trim(), password);
        if (user == null) {
            throw new AuthenticationException("Invalid username or password.");
        }
        return user;
    }

    public void registerUser(String username, String password, String role, Integer studentId) 
            throws DatabaseException, InvalidDataException {
        
        if (username == null || username.trim().isEmpty()) {
            throw new InvalidDataException("Username cannot be empty.");
        }
        if (username.contains(" ")) {
            throw new InvalidDataException("Username cannot contain spaces.");
        }
        if (password == null || password.length() < 6) {
            throw new InvalidDataException("Password must be at least 6 characters long.");
        }
        if (!"FACULTY".equalsIgnoreCase(role) && !"STUDENT".equalsIgnoreCase(role)) {
            throw new InvalidDataException("Invalid role. Must be FACULTY or STUDENT.");
        }
        
        if (userDAO.exists(username)) {
            throw new InvalidDataException("Username '" + username + "' is already taken.");
        }

        User user = new User();
        user.setUsername(username.trim());
        user.setPassword(password);
        user.setRole(role.toUpperCase());
        user.setStudentId(studentId);

        boolean success = userDAO.register(user);
        if (!success) {
            throw new DatabaseException("Failed to register user record in database.");
        }
    }
}
