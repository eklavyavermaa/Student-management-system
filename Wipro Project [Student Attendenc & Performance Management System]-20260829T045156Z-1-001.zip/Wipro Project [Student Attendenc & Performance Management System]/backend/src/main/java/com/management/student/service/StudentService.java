package com.management.student.service;

import com.management.student.dao.StudentDAO;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Student;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Handles business validation and operations for student profiles.
 * Maintains an in-memory Collections buffer for temporary student records.
 */
public class StudentService {
    private final StudentDAO studentDAO;
    
    public StudentService() {
        this.studentDAO = new StudentDAO();
    }

    public StudentService(StudentDAO studentDAO) {
        this.studentDAO = studentDAO;
    }
    
    // Java Collections buffer for temporary student records
    private final List<Student> tempBuffer = new ArrayList<>();

    // Regular expressions for validations
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    private static final Pattern PHONE_PATTERN = Pattern.compile("^\\+?[0-9]{10,15}$");

    /**
     * Validates student attributes. Throws InvalidDataException on failure.
     */
    public void validateStudent(Student student) throws InvalidDataException {
        if (student == null) {
            throw new InvalidDataException("Student data cannot be null.");
        }
        if (student.getRollNo() == null || student.getRollNo().trim().isEmpty()) {
            throw new InvalidDataException("Roll Number cannot be empty.");
        }
        if (student.getRollNo().contains(" ")) {
            throw new InvalidDataException("Roll Number cannot contain spaces.");
        }
        if (student.getName() == null || student.getName().trim().isEmpty()) {
            throw new InvalidDataException("Student Name cannot be empty.");
        }
        if (student.getEmail() == null || !EMAIL_PATTERN.matcher(student.getEmail()).matches()) {
            throw new InvalidDataException("Invalid Email Address format: " + student.getEmail());
        }
        if (student.getPhone() == null || !PHONE_PATTERN.matcher(student.getPhone()).matches()) {
            throw new InvalidDataException("Invalid Phone Number (Must be 10-15 digits): " + student.getPhone());
        }
        if (student.getDepartment() == null || student.getDepartment().trim().isEmpty()) {
            throw new InvalidDataException("Department cannot be empty.");
        }
    }

    /**
     * Adds a student directly to the database.
     */
    public int addStudent(Student student) throws DatabaseException, InvalidDataException {
        validateStudent(student);
        // Check if Roll No already exists
        if (studentDAO.findByRollNo(student.getRollNo()) != null) {
            throw new InvalidDataException("Student with Roll Number '" + student.getRollNo() + "' already exists.");
        }
        return studentDAO.addStudent(student);
    }

    /**
     * Updates student profile details in the database.
     */
    public void updateStudent(Student student) throws DatabaseException, InvalidDataException {
        validateStudent(student);
        Student existing = studentDAO.findByRollNo(student.getRollNo());
        if (existing == null) {
            throw new InvalidDataException("Student with Roll Number '" + student.getRollNo() + "' not found.");
        }
        studentDAO.updateStudent(student);
    }

    /**
     * Deletes student profile details from the database.
     */
    public void deleteStudent(String rollNo) throws DatabaseException, InvalidDataException {
        if (rollNo == null || rollNo.trim().isEmpty()) {
            throw new InvalidDataException("Roll Number is required to delete.");
        }
        Student existing = studentDAO.findByRollNo(rollNo);
        if (existing == null) {
            throw new InvalidDataException("Student with Roll Number '" + rollNo + "' not found.");
        }
        studentDAO.deleteStudentByRollNo(rollNo);
    }

    /**
     * Search student by name or roll number.
     */
    public List<Student> searchStudents(String query) throws DatabaseException {
        if (query == null || query.trim().isEmpty()) {
            return studentDAO.getAllStudents();
        }
        return studentDAO.searchStudents(query.trim());
    }

    public Student findStudentByRollNo(String rollNo) throws DatabaseException {
        if (rollNo == null || rollNo.trim().isEmpty()) {
            return null;
        }
        return studentDAO.findByRollNo(rollNo.trim());
    }

    public Student findStudentById(int id) throws DatabaseException {
        return studentDAO.findById(id);
    }

    public List<Student> getAllStudents() throws DatabaseException {
        return studentDAO.getAllStudents();
    }

    // --- Temporary List Collections Buffer Operations ---

    /**
     * Adds a student to the temporary collection buffer.
     */
    public void addTemporaryStudent(Student student) throws InvalidDataException, DatabaseException {
        validateStudent(student);
        // Check if exists in DB
        if (studentDAO.findByRollNo(student.getRollNo()) != null) {
            throw new InvalidDataException("Student with Roll Number '" + student.getRollNo() + "' already exists in database.");
        }
        // Check if exists in temp buffer
        for (Student s : tempBuffer) {
            if (s.getRollNo().equalsIgnoreCase(student.getRollNo())) {
                throw new InvalidDataException("Student with Roll Number '" + student.getRollNo() + "' already exists in temporary buffer.");
            }
        }
        tempBuffer.add(student);
    }

    /**
     * Retrieves all temporary records in the buffer.
     */
    public List<Student> getTemporaryStudents() {
        return new ArrayList<>(tempBuffer); // Return a copy of the buffer List
    }

    /**
     * Commits all cached student records in the collections buffer to the database.
     * Returns the count of students saved.
     */
    public int commitTemporaryStudents() throws DatabaseException {
        int count = 0;
        List<String> errors = new ArrayList<>();
        
        for (Student s : tempBuffer) {
            try {
                // If it wasn't added by someone else in the meantime
                if (studentDAO.findByRollNo(s.getRollNo()) == null) {
                    studentDAO.addStudent(s);
                    count++;
                } else {
                    errors.add("Roll No " + s.getRollNo() + " (already exists)");
                }
            } catch (DatabaseException e) {
                errors.add("Roll No " + s.getRollNo() + " (" + e.getMessage() + ")");
            }
        }
        
        tempBuffer.clear(); // Clear the collections buffer
        
        if (!errors.isEmpty()) {
            System.out.println("[WARN] Batch commit finished with issues: " + String.join(", ", errors));
        }
        return count;
    }

    /**
     * Clears all cached student records in the buffer.
     */
    public void clearTemporaryStudents() {
        tempBuffer.clear();
    }
}
