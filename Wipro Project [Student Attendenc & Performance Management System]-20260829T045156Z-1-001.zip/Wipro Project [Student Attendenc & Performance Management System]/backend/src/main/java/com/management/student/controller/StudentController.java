package com.management.student.controller;

import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Student;
import com.management.student.service.StudentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles REST endpoints for Student profile CRUD and collections temporary buffer.
 */
@RestController
@RequestMapping("/api/students")
@CrossOrigin(origins = "*")
public class StudentController {
    private final StudentService studentService = new StudentService();

    @GetMapping
    public ResponseEntity<?> getAllStudents() {
        try {
            List<Student> list = studentService.getAllStudents();
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @GetMapping("/search")
    public ResponseEntity<?> searchStudents(@RequestParam(value = "query", defaultValue = "") String query) {
        try {
            List<Student> list = studentService.searchStudents(query);
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<?> getStudentById(@PathVariable("id") int id) {
        try {
            Student student = studentService.findStudentById(id);
            if (student == null) {
                return ResponseEntity.status(404).body(new AuthController.ErrorResponse("Student not found."));
            }
            return ResponseEntity.ok(student);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @GetMapping("/roll/{rollNo}")
    public ResponseEntity<?> getStudentByRollNo(@PathVariable("rollNo") String rollNo) {
        try {
            Student student = studentService.findStudentByRollNo(rollNo);
            if (student == null) {
                return ResponseEntity.status(404).body(new AuthController.ErrorResponse("Student not found."));
            }
            return ResponseEntity.ok(student);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping
    public ResponseEntity<?> addStudent(@RequestBody Student student) {
        try {
            int id = studentService.addStudent(student);
            student.setId(id);
            return ResponseEntity.ok(student);
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PutMapping
    public ResponseEntity<?> updateStudent(@RequestBody Student student) {
        try {
            studentService.updateStudent(student);
            return ResponseEntity.ok(new AuthController.MessageResponse("Student profile updated successfully."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @DeleteMapping("/{rollNo}")
    public ResponseEntity<?> deleteStudent(@PathVariable("rollNo") String rollNo) {
        try {
            studentService.deleteStudent(rollNo);
            return ResponseEntity.ok(new AuthController.MessageResponse("Student deleted successfully."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    // --- Collections Temporary Buffer Endpoints ---

    @GetMapping("/temp")
    public ResponseEntity<?> getTemporaryStudents() {
        return ResponseEntity.ok(studentService.getTemporaryStudents());
    }

    @PostMapping("/temp")
    public ResponseEntity<?> addTemporaryStudent(@RequestBody Student student) {
        try {
            studentService.addTemporaryStudent(student);
            return ResponseEntity.ok(new AuthController.MessageResponse("Student added to temporary Collections buffer."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/temp/commit")
    public ResponseEntity<?> commitTemporaryStudents() {
        try {
            int count = studentService.commitTemporaryStudents();
            return ResponseEntity.ok(new AuthController.MessageResponse("Committed " + count + " student profiles to database."));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @DeleteMapping("/temp/clear")
    public ResponseEntity<?> clearTemporaryStudents() {
        studentService.clearTemporaryStudents();
        return ResponseEntity.ok(new AuthController.MessageResponse("Temporary buffer cleared."));
    }
}
