package com.management.student.dao;

import com.management.student.exception.DatabaseException;
import com.management.student.model.Student;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles database operations (CRUD) for Student records.
 */
public class StudentDAO {

    /**
     * Adds a student to the database. Returns the generated auto-increment ID.
     */
    public int addStudent(Student student) throws DatabaseException {
        String sql = "INSERT INTO students (roll_no, name, email, phone, department) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, student.getRollNo());
            pstmt.setString(2, student.getName());
            pstmt.setString(3, student.getEmail());
            pstmt.setString(4, student.getPhone());
            pstmt.setString(5, student.getDepartment());

            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    student.setId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add student roll no: " + student.getRollNo(), e);
        }
        return -1;
    }

    /**
     * Updates an existing student record.
     */
    public boolean updateStudent(Student student) throws DatabaseException {
        String sql = "UPDATE students SET name = ?, email = ?, phone = ?, department = ? WHERE roll_no = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setString(2, student.getEmail());
            pstmt.setString(3, student.getPhone());
            pstmt.setString(4, student.getDepartment());
            pstmt.setString(5, student.getRollNo());

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update student: " + student.getRollNo(), e);
        }
    }

    /**
     * Deletes a student record using Roll No.
     */
    public boolean deleteStudentByRollNo(String rollNo) throws DatabaseException {
        String sql = "DELETE FROM students WHERE roll_no = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, rollNo);
            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete student with roll no: " + rollNo, e);
        }
    }

    /**
     * Searches students by Roll No or Name. Uses pattern matching (LIKE).
     */
    public List<Student> searchStudents(String query) throws DatabaseException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT id, roll_no, name, email, phone, department FROM students WHERE roll_no LIKE ? OR name LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            String wildCardQuery = "%" + query + "%";
            pstmt.setString(1, wildCardQuery);
            pstmt.setString(2, wildCardQuery);

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setRollNo(rs.getString("roll_no"));
                    student.setName(rs.getString("name"));
                    student.setEmail(rs.getString("email"));
                    student.setPhone(rs.getString("phone"));
                    student.setDepartment(rs.getString("department"));
                    list.add(student);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error during student search", e);
        }
        return list;
    }

    /**
     * Retrieves all student records.
     */
    public List<Student> getAllStudents() throws DatabaseException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT id, roll_no, name, email, phone, department FROM students ORDER BY roll_no ASC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Student student = new Student();
                student.setId(rs.getInt("id"));
                student.setRollNo(rs.getString("roll_no"));
                student.setName(rs.getString("name"));
                student.setEmail(rs.getString("email"));
                student.setPhone(rs.getString("phone"));
                student.setDepartment(rs.getString("department"));
                list.add(student);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving student list", e);
        }
        return list;
    }

    /**
     * Finds a student by Roll No. Returns null if not found.
     */
    public Student findByRollNo(String rollNo) throws DatabaseException {
        String sql = "SELECT id, roll_no, name, email, phone, department FROM students WHERE roll_no = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, rollNo);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setRollNo(rs.getString("roll_no"));
                    student.setName(rs.getString("name"));
                    student.setEmail(rs.getString("email"));
                    student.setPhone(rs.getString("phone"));
                    student.setDepartment(rs.getString("department"));
                    return student;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error looking up student roll no: " + rollNo, e);
        }
        return null;
    }

    /**
     * Finds a student by internal database ID.
     */
    public Student findById(int id) throws DatabaseException {
        String sql = "SELECT id, roll_no, name, email, phone, department FROM students WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setRollNo(rs.getString("roll_no"));
                    student.setName(rs.getString("name"));
                    student.setEmail(rs.getString("email"));
                    student.setPhone(rs.getString("phone"));
                    student.setDepartment(rs.getString("department"));
                    return student;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error looking up student ID: " + id, e);
        }
        return null;
    }
}
