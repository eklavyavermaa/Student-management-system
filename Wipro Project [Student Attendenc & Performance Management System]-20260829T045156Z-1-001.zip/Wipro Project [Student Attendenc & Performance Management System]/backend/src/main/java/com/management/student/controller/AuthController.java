package com.management.student.controller;

import com.management.student.exception.AuthenticationException;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Student;
import com.management.student.model.User;
import com.management.student.service.StudentService;
import com.management.student.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Handles endpoints for logins and registration.
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    private final UserService userService = new UserService();
    private final StudentService studentService = new StudentService();

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            User user = userService.login(request.username, request.password);
            return ResponseEntity.ok(user);
        } catch (AuthenticationException e) {
            return ResponseEntity.status(401).body(new ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/register-student")
    public ResponseEntity<?> registerStudent(@RequestBody StudentRegisterRequest request) {
        try {
            // Find or create student profile first
            Student student = studentService.findStudentByRollNo(request.rollNo);
            if (student == null) {
                student = new Student(request.name, request.email, request.phone, request.rollNo, request.department);
                int studentId = studentService.addStudent(student);
                student.setId(studentId);
            }
            
            userService.registerUser(request.username, request.password, "STUDENT", student.getId());
            return ResponseEntity.ok(new MessageResponse("Student registered successfully."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/register-faculty")
    public ResponseEntity<?> registerFaculty(@RequestBody FacultyRegisterRequest request) {
        try {
            userService.registerUser(request.username, request.password, "FACULTY", null);
            return ResponseEntity.ok(new MessageResponse("Faculty account created successfully."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new ErrorResponse(e.getMessage()));
        }
    }

    // --- DTO Classes ---
    public static class LoginRequest {
        public String username;
        public String password;
    }

    public static class StudentRegisterRequest {
        public String username;
        public String password;
        public String rollNo;
        public String name;
        public String email;
        public String phone;
        public String department;
    }

    public static class FacultyRegisterRequest {
        public String username;
        public String password;
    }

    public static class ErrorResponse {
        private String error;
        public ErrorResponse(String error) { this.error = error; }
        public String getError() { return error; }
    }

    public static class MessageResponse {
        private String message;
        public MessageResponse(String message) { this.message = message; }
        public String getMessage() { return message; }
    }
}
