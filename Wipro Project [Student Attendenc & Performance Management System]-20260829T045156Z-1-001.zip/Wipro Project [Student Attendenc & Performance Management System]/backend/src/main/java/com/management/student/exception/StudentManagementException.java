package com.management.student.exception;

/**
 * Base exception for the Student Attendance & Performance Management System.
 */
public class StudentManagementException extends Exception {
    public StudentManagementException(String message) {
        super(message);
    }

    public StudentManagementException(String message, Throwable cause) {
        super(message, cause);
    }
}
