package com.management.student.dao;

import com.management.student.exception.DatabaseException;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Manages database properties and provides JDBC Connection objects.
 */
public class DBConnection {
    private static final String PROPERTIES_FILE = "db.properties";
    private static final Properties properties = new Properties();
    private static double attendanceThreshold = 75.0;

    static {
        loadProperties();
    }

    private static void loadProperties() {
        File file = new File(PROPERTIES_FILE);
        if (!file.exists()) {
            // Write default template to assist user setup
            try (FileOutputStream out = new FileOutputStream(file)) {
                properties.setProperty("db.url", "jdbc:mysql://localhost:3306/");
                properties.setProperty("db.name", "student_attendance_performance_db");
                properties.setProperty("db.user", "root");
                properties.setProperty("db.password", "password");
                properties.setProperty("db.attendance.threshold", "75.0");
                properties.store(out, "Auto-generated default DB Properties. Change password as needed.");
                System.out.println("[INFO] db.properties was missing. A default template has been created at: " 
                        + file.getAbsolutePath());
            } catch (IOException e) {
                System.err.println("[ERROR] Failed to create default db.properties: " + e.getMessage());
            }
        } else {
            try (FileInputStream in = new FileInputStream(file)) {
                properties.load(in);
                String thresholdStr = properties.getProperty("db.attendance.threshold", "75.0");
                attendanceThreshold = Double.parseDouble(thresholdStr);
            } catch (IOException | NumberFormatException e) {
                System.err.println("[WARN] Failed to load/parse properties, using defaults. Error: " + e.getMessage());
            }
        }
    }

    /**
     * Connects directly to the MySQL server without selecting a specific database.
     * Useful for checking if the database exists and running initialization.
     */
    public static Connection getBaseConnection() throws DatabaseException {
        String url = properties.getProperty("db.url", "jdbc:mysql://localhost:3306/");
        String user = properties.getProperty("db.user", "root");
        String pass = properties.getProperty("db.password", "password");

        try {
            // Load driver explicitly (good practice in core Java JDBC)
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException e) {
            throw new DatabaseException("MySQL JDBC Driver not found in classpath. Ensure Maven dependencies are loaded.", e);
        } catch (SQLException e) {
            throw new DatabaseException("Could not connect to MySQL server at: " + url + " (User: " + user + "). Ensure MySQL is running and password is correct.", e);
        }
    }

    /**
     * Connects to the specific application database.
     */
    public static Connection getConnection() throws DatabaseException {
        String baseUrl = properties.getProperty("db.url", "jdbc:mysql://localhost:3306/");
        String dbName = properties.getProperty("db.name", "student_attendance_performance_db");
        String user = properties.getProperty("db.user", "root");
        String pass = properties.getProperty("db.password", "password");

        // Ensure database URL ends with a slash
        String url = baseUrl;
        if (!url.endsWith("/")) {
            url += "/";
        }
        url += dbName + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException e) {
            throw new DatabaseException("MySQL JDBC Driver not found.", e);
        } catch (SQLException e) {
            throw new DatabaseException("Failed to connect to database: " + dbName + ". Run DBInitializer setup first.", e);
        }
    }

    public static double getAttendanceThreshold() {
        return attendanceThreshold;
    }
}
