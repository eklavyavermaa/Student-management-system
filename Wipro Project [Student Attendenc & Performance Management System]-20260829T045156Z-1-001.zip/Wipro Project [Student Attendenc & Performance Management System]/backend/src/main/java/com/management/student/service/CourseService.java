package com.management.student.service;

import com.management.student.dao.CourseDAO;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Course;

import java.util.List;

/**
 * Handles validation and business operations for academic Courses.
 */
public class CourseService {
    private final CourseDAO courseDAO = new CourseDAO();

    public List<Course> getAllCourses() throws DatabaseException {
        return courseDAO.getAllCourses();
    }

    public Course findCourseById(int id) throws DatabaseException {
        return courseDAO.findById(id);
    }

    public Course findCourseByCode(String code) throws DatabaseException {
        return courseDAO.findByCode(code);
    }

    public int addCourse(Course course) throws DatabaseException, InvalidDataException {
        if (course == null) {
            throw new InvalidDataException("Course details cannot be null.");
        }
        if (course.getCourseCode() == null || course.getCourseCode().trim().isEmpty()) {
            throw new InvalidDataException("Course Code cannot be empty.");
        }
        if (course.getCourseName() == null || course.getCourseName().trim().isEmpty()) {
            throw new InvalidDataException("Course Name cannot be empty.");
        }
        if (courseDAO.findByCode(course.getCourseCode().trim()) != null) {
            throw new InvalidDataException("Course with Code '" + course.getCourseCode() + "' already exists.");
        }
        return courseDAO.addCourse(course);
    }
}
