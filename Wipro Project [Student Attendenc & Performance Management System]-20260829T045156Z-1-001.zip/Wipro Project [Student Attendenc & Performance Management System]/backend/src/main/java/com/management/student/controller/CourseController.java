package com.management.student.controller;

import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Course;
import com.management.student.service.CourseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles REST endpoints for Course operations.
 */
@RestController
@RequestMapping("/api/courses")
@CrossOrigin(origins = "*")
public class CourseController {
    private final CourseService courseService = new CourseService();

    @GetMapping
    public ResponseEntity<?> getAllCourses() {
        try {
            List<Course> list = courseService.getAllCourses();
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping
    public ResponseEntity<?> addCourse(@RequestBody Course course) {
        try {
            int id = courseService.addCourse(course);
            course.setId(id);
            return ResponseEntity.ok(course);
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }
}
