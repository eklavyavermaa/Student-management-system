package com.management.student.dao;

import com.management.student.exception.DatabaseException;
import com.management.student.model.Course;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles database operations for Courses.
 */
public class CourseDAO {

    public List<Course> getAllCourses() throws DatabaseException {
        List<Course> list = new ArrayList<>();
        String sql = "SELECT id, course_code, course_name FROM courses ORDER BY course_code ASC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Course(
                        rs.getInt("id"),
                        rs.getString("course_code"),
                        rs.getString("course_name")
                ));
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to retrieve course list", e);
        }
        return list;
    }

    public Course findById(int id) throws DatabaseException {
        String sql = "SELECT id, course_code, course_name FROM courses WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Course(
                            rs.getInt("id"),
                            rs.getString("course_code"),
                            rs.getString("course_name")
                    );
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to lookup course by ID: " + id, e);
        }
        return null;
    }

    public Course findByCode(String code) throws DatabaseException {
        String sql = "SELECT id, course_code, course_name FROM courses WHERE course_code = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, code);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Course(
                            rs.getInt("id"),
                            rs.getString("course_code"),
                            rs.getString("course_name")
                    );
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to lookup course by code: " + code, e);
        }
        return null;
    }

    public int addCourse(Course course) throws DatabaseException {
        String sql = "INSERT INTO courses (course_code, course_name) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, course.getCourseCode());
            pstmt.setString(2, course.getCourseName());
            pstmt.executeUpdate();

            try (ResultSet keys = pstmt.getGeneratedKeys()) {
                if (keys.next()) {
                    int id = keys.getInt(1);
                    course.setId(id);
                    return id;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add course: " + course.getCourseCode(), e);
        }
        return -1;
    }
}
