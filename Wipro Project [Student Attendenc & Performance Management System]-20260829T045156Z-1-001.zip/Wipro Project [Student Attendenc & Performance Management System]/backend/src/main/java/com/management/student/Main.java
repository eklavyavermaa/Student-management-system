package com.management.student;

import com.management.student.dao.DBInitializer;
import com.management.student.exception.DatabaseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot entrypoint for the REST API Backend.
 */
@SpringBootApplication
public class Main {
    public static void main(String[] args) {
        System.out.println("Initializing Database schema. Please wait...");
        try {
            DBInitializer.initializeDatabase();
            System.out.println("Database and tables initialized successfully.");
        } catch (DatabaseException e) {
            System.err.println("\n[CRITICAL STARTUP ERROR] " + e.getMessage());
            if (e.getCause() != null) {
                System.err.println("Details: " + e.getCause().getMessage());
            }
            System.err.println("\n[SETUP INSTRUCTIONS]");
            System.err.println("1. Ensure MySQL server is running locally.");
            System.err.println("2. Check the connection configurations in 'db.properties' located in the project root folder.");
            System.err.println("3. Re-run the application after verifying credentials.");
            System.exit(1);
        }

        // Start the Spring Boot Web Server
        SpringApplication.run(Main.class, args);
    }
}
