package com.management.student.controller;

import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Marks;
import com.management.student.service.MarksService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Handles REST endpoints for recording and retrieving student grades.
 */
@RestController
@RequestMapping("/api/marks")
@CrossOrigin(origins = "*")
public class MarksController {
    private final MarksService marksService = new MarksService();

    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getMarksHistory(@PathVariable("studentId") int studentId) {
        try {
            List<Marks> list = marksService.getMarksHistory(studentId);
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/record")
    public ResponseEntity<?> recordMarks(@RequestBody MarksRecordRequest request) {
        try {
            marksService.recordMarks(
                    request.studentId,
                    request.courseId,
                    request.examType,
                    request.marksObtained,
                    request.maxMarks
            );
            return ResponseEntity.ok(new AuthController.MessageResponse("Marks recorded successfully."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    // --- DTO ---
    public static class MarksRecordRequest {
        public int studentId;
        public int courseId;
        public String examType;
        public double marksObtained;
        public double maxMarks;
    }
}
