package com.management.student.model;

import java.time.LocalDate;

/**
 * Represents an attendance record for a student in a specific course.
 */
public class Attendance {
    private Integer id;
    private Integer studentId;
    private Integer courseId; // Linked to Course
    private LocalDate date;
    private String status; // "PRESENT" or "ABSENT"

    public Attendance() {
    }

    public Attendance(Integer studentId, Integer courseId, LocalDate date, String status) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.date = date;
        this.status = status;
    }

    public Attendance(Integer id, Integer studentId, Integer courseId, LocalDate date, String status) {
        this.id = id;
        this.studentId = studentId;
        this.courseId = courseId;
        this.date = date;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Date: " + date + ", Status: " + status + ", Course ID: " + courseId;
    }
}
