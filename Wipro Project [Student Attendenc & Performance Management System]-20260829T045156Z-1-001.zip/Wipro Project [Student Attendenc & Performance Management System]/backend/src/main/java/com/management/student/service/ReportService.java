package com.management.student.service;

import com.management.student.dao.DBConnection;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Attendance;
import com.management.student.model.Course;
import com.management.student.model.Marks;
import com.management.student.model.PerformanceReport;
import com.management.student.model.Student;

import java.util.ArrayList;
import java.util.List;

/**
 * Service to aggregate student records course-wise and generate full PerformanceReports.
 */
public class ReportService {
    private final StudentService studentService = new StudentService();
    private final CourseService courseService = new CourseService();
    private final AttendanceService attendanceService = new AttendanceService();
    private final MarksService marksService = new MarksService();

    public PerformanceReport generateReport(String rollNo) throws DatabaseException, InvalidDataException {
        if (rollNo == null || rollNo.trim().isEmpty()) {
            throw new InvalidDataException("Roll Number cannot be empty.");
        }

        Student student = studentService.findStudentByRollNo(rollNo.trim());
        if (student == null) {
            throw new InvalidDataException("Student with Roll Number '" + rollNo + "' not found.");
        }

        List<Course> allCourses = courseService.getAllCourses();
        List<PerformanceReport.CourseSummary> courseSummaries = new ArrayList<>();

        double overallAttendancePctSum = 0.0;
        int activeCoursesForAttendanceCount = 0;
        double gpaSum = 0.0;
        int activeCoursesForGradesCount = 0;
        boolean hasOverallShortage = false;

        for (Course course : allCourses) {
            List<Attendance> attendanceHistory = attendanceService.getAttendanceHistoryForCourse(student.getId(), course.getId());
            List<Marks> marksHistory = marksService.getMarksHistoryForCourse(student.getId(), course.getId());

            int totalClasses = attendanceHistory.size();
            int presentClasses = (int) attendanceHistory.stream()
                    .filter(a -> "PRESENT".equalsIgnoreCase(a.getStatus()))
                    .count();

            double attendancePercentage = 100.0; // Baseline
            boolean hasShortage = false;

            if (totalClasses > 0) {
                attendancePercentage = ((double) presentClasses / totalClasses) * 100.0;
                hasShortage = attendancePercentage < DBConnection.getAttendanceThreshold();
                
                overallAttendancePctSum += attendancePercentage;
                activeCoursesForAttendanceCount++;
                if (hasShortage) {
                    hasOverallShortage = true;
                }
            }

            double averageGradePercentage = 0.0;
            if (!marksHistory.isEmpty()) {
                double totalObtained = marksHistory.stream().mapToDouble(Marks::getMarksObtained).sum();
                double totalMax = marksHistory.stream().mapToDouble(Marks::getMaxMarks).sum();
                if (totalMax > 0) {
                    averageGradePercentage = (totalObtained / totalMax) * 100.0;
                }
                
                // Calculate GPA for this course (10-point scale)
                double gpa = getGpaFromPercentage(averageGradePercentage);
                gpaSum += gpa;
                activeCoursesForGradesCount++;
            }

            courseSummaries.add(new PerformanceReport.CourseSummary(
                    course,
                    attendanceHistory,
                    marksHistory,
                    totalClasses,
                    presentClasses,
                    attendancePercentage,
                    hasShortage,
                    averageGradePercentage
            ));
        }

        double overallAttendancePercentage = activeCoursesForAttendanceCount > 0 
                ? (overallAttendancePctSum / activeCoursesForAttendanceCount) 
                : 100.0;
        
        double cgpa = activeCoursesForGradesCount > 0 
                ? (gpaSum / activeCoursesForGradesCount) 
                : 0.0;

        return new PerformanceReport(student, courseSummaries, overallAttendancePercentage, hasOverallShortage, cgpa);
    }

    private double getGpaFromPercentage(double pct) {
        if (pct >= 90) return 10.0;
        if (pct >= 80) return 9.0;
        if (pct >= 70) return 8.0;
        if (pct >= 60) return 7.0;
        if (pct >= 50) return 6.0;
        if (pct >= 40) return 5.0;
        return 0.0;
    }
}
