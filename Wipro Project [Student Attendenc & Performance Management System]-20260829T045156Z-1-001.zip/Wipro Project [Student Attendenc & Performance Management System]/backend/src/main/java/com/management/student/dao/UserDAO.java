package com.management.student.dao;

import com.management.student.exception.DatabaseException;
import com.management.student.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Handles database operations for User login and registration.
 */
public class UserDAO {

    /**
     * Authenticates a user with username and password. Returns User object if successful, null otherwise.
     */
    public User authenticate(String username, String password) throws DatabaseException {
        String sql = "SELECT id, username, password, role, student_id FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setRole(rs.getString("role"));
                    
                    int studentId = rs.getInt("student_id");
                    if (!rs.wasNull()) {
                        user.setStudentId(studentId);
                    }
                    return user;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error during user authentication", e);
        }
        return null;
    }

    /**
     * Registers a new user. Returns true if successful.
     */
    public boolean register(User user) throws DatabaseException {
        String sql = "INSERT INTO users (username, password, role, student_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getRole());
            
            if (user.getStudentId() != null) {
                pstmt.setInt(4, user.getStudentId());
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to register user: " + user.getUsername(), e);
        }
    }

    /**
     * Checks if a username already exists.
     */
    public boolean exists(String username) throws DatabaseException {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error verifying user existence", e);
        }
        return false;
    }
}
