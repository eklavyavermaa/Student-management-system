package com.management.student.model;

import java.util.List;

/**
 * Aggregated report details for a student, compiled course-wise.
 */
public class PerformanceReport {
    private Student student;
    private List<CourseSummary> courseSummaries;
    private double overallAttendancePercentage;
    private boolean hasOverallShortage;
    private double cgpa;

    public PerformanceReport() {
    }

    public PerformanceReport(Student student, List<CourseSummary> courseSummaries, 
                             double overallAttendancePercentage, boolean hasOverallShortage, double cgpa) {
        this.student = student;
        this.courseSummaries = courseSummaries;
        this.overallAttendancePercentage = overallAttendancePercentage;
        this.hasOverallShortage = hasOverallShortage;
        this.cgpa = cgpa;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public List<CourseSummary> getCourseSummaries() {
        return courseSummaries;
    }

    public void setCourseSummaries(List<CourseSummary> courseSummaries) {
        this.courseSummaries = courseSummaries;
    }

    public double getOverallAttendancePercentage() {
        return overallAttendancePercentage;
    }

    public void setOverallAttendancePercentage(double overallAttendancePercentage) {
        this.overallAttendancePercentage = overallAttendancePercentage;
    }

    public boolean isHasOverallShortage() {
        return hasOverallShortage;
    }

    public void setHasOverallShortage(boolean hasOverallShortage) {
        this.hasOverallShortage = hasOverallShortage;
    }

    public double getCgpa() {
        return cgpa;
    }

    public void setCgpa(double cgpa) {
        this.cgpa = cgpa;
    }

    /**
     * Inner DTO representing course-specific statistics.
     */
    public static class CourseSummary {
        private Course course;
        private List<Attendance> attendanceHistory;
        private List<Marks> marksHistory;
        private int totalClasses;
        private int presentClasses;
        private double attendancePercentage;
        private boolean hasShortage;
        private double averageGradePercentage;

        public CourseSummary() {
        }

        public CourseSummary(Course course, List<Attendance> attendanceHistory, List<Marks> marksHistory, 
                             int totalClasses, int presentClasses, double attendancePercentage, 
                             boolean hasShortage, double averageGradePercentage) {
            this.course = course;
            this.attendanceHistory = attendanceHistory;
            this.marksHistory = marksHistory;
            this.totalClasses = totalClasses;
            this.presentClasses = presentClasses;
            this.attendancePercentage = attendancePercentage;
            this.hasShortage = hasShortage;
            this.averageGradePercentage = averageGradePercentage;
        }

        public Course getCourse() {
            return course;
        }

        public void setCourse(Course course) {
            this.course = course;
        }

        public List<Attendance> getAttendanceHistory() {
            return attendanceHistory;
        }

        public void setAttendanceHistory(List<Attendance> attendanceHistory) {
            this.attendanceHistory = attendanceHistory;
        }

        public List<Marks> getMarksHistory() {
            return marksHistory;
        }

        public void setMarksHistory(List<Marks> marksHistory) {
            this.marksHistory = marksHistory;
        }

        public int getTotalClasses() {
            return totalClasses;
        }

        public void setTotalClasses(int totalClasses) {
            this.totalClasses = totalClasses;
        }

        public int getPresentClasses() {
            return presentClasses;
        }

        public void setPresentClasses(int presentClasses) {
            this.presentClasses = presentClasses;
        }

        public double getAttendancePercentage() {
            return attendancePercentage;
        }

        public void setAttendancePercentage(double attendancePercentage) {
            this.attendancePercentage = attendancePercentage;
        }

        public boolean isHasShortage() {
            return hasShortage;
        }

        public void setHasShortage(boolean hasShortage) {
            this.hasShortage = hasShortage;
        }

        public double getAverageGradePercentage() {
            return averageGradePercentage;
        }

        public void setAverageGradePercentage(double averageGradePercentage) {
            this.averageGradePercentage = averageGradePercentage;
        }
    }
}
