package com.management.student.model;

/**
 * Represents academic marks scored by a student in a course exam or assignment.
 */
public class Marks {
    private Integer id;
    private Integer studentId;
    private Integer courseId; // Linked to Course
    private String examType; // "MST_1", "MST_2", "ASSIGNMENT_1", "ASSIGNMENT_2"
    private Double marksObtained;
    private Double maxMarks;

    public Marks() {
    }

    public Marks(Integer studentId, Integer courseId, String examType, Double marksObtained, Double maxMarks) {
        this.studentId = studentId;
        this.courseId = courseId;
        this.examType = examType;
        this.marksObtained = marksObtained;
        this.maxMarks = maxMarks;
    }

    public Marks(Integer id, Integer studentId, Integer courseId, String examType, Double marksObtained, Double maxMarks) {
        this.id = id;
        this.studentId = studentId;
        this.courseId = courseId;
        this.examType = examType;
        this.marksObtained = marksObtained;
        this.maxMarks = maxMarks;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public String getExamType() {
        return examType;
    }

    public void setExamType(String examType) {
        this.examType = examType;
    }

    public Double getMarksObtained() {
        return marksObtained;
    }

    public void setMarksObtained(Double marksObtained) {
        this.marksObtained = marksObtained;
    }

    public Double getMaxMarks() {
        return maxMarks;
    }

    public void setMaxMarks(Double maxMarks) {
        this.maxMarks = maxMarks;
    }

    @Override
    public String toString() {
        return examType + " in Course " + courseId + ": " + marksObtained + " / " + maxMarks + 
               " (" + String.format("%.2f", (marksObtained/maxMarks)*100) + "%)";
    }
}
