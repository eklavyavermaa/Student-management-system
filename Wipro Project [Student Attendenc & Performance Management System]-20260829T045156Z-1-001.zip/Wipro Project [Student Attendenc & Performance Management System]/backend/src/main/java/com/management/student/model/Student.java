package com.management.student.model;

/**
 * Represents a Student. Inherits common attributes from Person.
 */
public class Student extends Person {
    private Integer id;
    private String rollNo;
    private String department;

    public Student() {
        super();
    }

    public Student(String name, String email, String phone, String rollNo, String department) {
        super(name, email, phone);
        this.rollNo = rollNo;
        this.department = department;
    }

    public Student(Integer id, String name, String email, String phone, String rollNo, String department) {
        super(name, email, phone);
        this.id = id;
        this.rollNo = rollNo;
        this.department = department;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Roll No: " + rollNo + ", " + super.toString() + ", Department: " + department;
    }
}
