package com.management.student.controller;

import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.PerformanceReport;
import com.management.student.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Handles REST endpoints for compiling student performance reports.
 */
@RestController
@RequestMapping("/api/reports")
@CrossOrigin(origins = "*")
public class ReportController {
    private final ReportService reportService = new ReportService();

    @GetMapping("/student/{rollNo}")
    public ResponseEntity<?> generateReport(@PathVariable("rollNo") String rollNo) {
        try {
            PerformanceReport report = reportService.generateReport(rollNo);
            return ResponseEntity.ok(report);
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }
}
