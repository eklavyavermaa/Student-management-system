package com.management.student.service;

import com.management.student.dao.CourseDAO;
import com.management.student.dao.MarksDAO;
import com.management.student.dao.StudentDAO;
import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Marks;

import java.util.Arrays;
import java.util.List;

/**
 * Handles validation and business operations for student marks course-wise.
 */
public class MarksService {
    private final MarksDAO marksDAO = new MarksDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final CourseDAO courseDAO = new CourseDAO();

    private static final List<String> VALID_EXAM_TYPES = Arrays.asList(
            "MST_1", "MST_2", "ASSIGNMENT_1", "ASSIGNMENT_2"
    );

    public void recordMarks(int studentId, int courseId, String examType, Double marksObtained, Double maxMarks) 
            throws DatabaseException, InvalidDataException {
        
        validateMarks(studentId, courseId, examType, marksObtained, maxMarks);

        Marks marks = new Marks(studentId, courseId, examType.toUpperCase(), marksObtained, maxMarks);
        boolean success = marksDAO.saveOrUpdateMarks(marks);
        if (!success) {
            throw new DatabaseException("Failed to record marks in database.");
        }
    }

    private void validateMarks(int studentId, int courseId, String examType, Double marksObtained, Double maxMarks) 
            throws InvalidDataException, DatabaseException {
        
        if (studentDAO.findById(studentId) == null) {
            throw new InvalidDataException("Student with ID " + studentId + " does not exist.");
        }
        if (courseDAO.findById(courseId) == null) {
            throw new InvalidDataException("Course with ID " + courseId + " does not exist.");
        }
        if (examType == null || !VALID_EXAM_TYPES.contains(examType.toUpperCase())) {
            throw new InvalidDataException("Invalid Exam Type. Must be one of: " + VALID_EXAM_TYPES);
        }
        if (maxMarks == null || maxMarks <= 0) {
            throw new InvalidDataException("Max Marks must be greater than zero.");
        }
        if (marksObtained == null || marksObtained < 0 || marksObtained > maxMarks) {
            throw new InvalidDataException("Marks Obtained must be between 0 and Max Marks (" + maxMarks + ").");
        }
    }

    public List<Marks> getMarksHistory(int studentId) throws DatabaseException {
        return marksDAO.getMarksHistory(studentId);
    }

    public List<Marks> getMarksHistoryForCourse(int studentId, int courseId) throws DatabaseException {
        return marksDAO.getMarksHistoryForCourse(studentId, courseId);
    }
}
