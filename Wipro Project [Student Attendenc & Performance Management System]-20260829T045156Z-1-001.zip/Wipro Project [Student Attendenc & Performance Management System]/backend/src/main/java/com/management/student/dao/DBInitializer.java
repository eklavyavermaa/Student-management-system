package com.management.student.dao;

import com.management.student.exception.DatabaseException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Initializes the database schema, handles tables resets/upgrades, and seeds default records.
 */
public class DBInitializer {

    public static void initializeDatabase() throws DatabaseException {
        // Step 1: Create database if not exists using base connection
        try (Connection conn = DBConnection.getBaseConnection();
             Statement stmt = conn.createStatement()) {
            
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS student_attendance_performance_db");
            System.out.println("[INFO] Database 'student_attendance_performance_db' verified/created.");
            
        } catch (SQLException e) {
            throw new DatabaseException("Failed to verify/create database schema", e);
        }

        // Step 2: Drop and recreate tables to apply schema upgrades for course-wise tracking
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            // Disable foreign key checks momentarily to run drop queries
            stmt.execute("SET FOREIGN_KEY_CHECKS = 0;");
            
            // Drop old tables to prevent conflicts during full-stack transition
            stmt.executeUpdate("DROP TABLE IF EXISTS marks;");
            stmt.executeUpdate("DROP TABLE IF EXISTS attendance;");
            stmt.executeUpdate("DROP TABLE IF EXISTS users;");
            stmt.executeUpdate("DROP TABLE IF EXISTS students;");
            stmt.executeUpdate("DROP TABLE IF EXISTS courses;");
            
            System.out.println("[INFO] Upgraded/Cleaned database tables for full-stack course-wise schema.");

            // Courses table
            String createCoursesTable = "CREATE TABLE IF NOT EXISTS courses (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "course_code VARCHAR(20) UNIQUE NOT NULL," +
                    "course_name VARCHAR(100) NOT NULL" +
                    ") ENGINE=InnoDB;";
            stmt.executeUpdate(createCoursesTable);

            // Students table
            String createStudentsTable = "CREATE TABLE IF NOT EXISTS students (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "roll_no VARCHAR(50) UNIQUE NOT NULL," +
                    "name VARCHAR(100) NOT NULL," +
                    "email VARCHAR(100) UNIQUE NOT NULL," +
                    "phone VARCHAR(15) NOT NULL," +
                    "department VARCHAR(50) NOT NULL" +
                    ") ENGINE=InnoDB;";
            stmt.executeUpdate(createStudentsTable);

            // Users table (for login credentials)
            String createUsersTable = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "username VARCHAR(50) UNIQUE NOT NULL," +
                    "password VARCHAR(255) NOT NULL," +
                    "role VARCHAR(20) NOT NULL," + // 'FACULTY' or 'STUDENT'
                    "student_id INT NULL," +
                    "FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE" +
                    ") ENGINE=InnoDB;";
            stmt.executeUpdate(createUsersTable);

            // Attendance table (Linked to Course)
            String createAttendanceTable = "CREATE TABLE IF NOT EXISTS attendance (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "student_id INT NOT NULL," +
                    "course_id INT NOT NULL," +
                    "date DATE NOT NULL," +
                    "status VARCHAR(10) NOT NULL," + // 'PRESENT' or 'ABSENT'
                    "FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE," +
                    "FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE," +
                    "UNIQUE KEY unique_student_course_date (student_id, course_id, date)" +
                    ") ENGINE=InnoDB;";
            stmt.executeUpdate(createAttendanceTable);

            // Marks table (Linked to Course)
            String createMarksTable = "CREATE TABLE IF NOT EXISTS marks (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "student_id INT NOT NULL," +
                    "course_id INT NOT NULL," +
                    "exam_type VARCHAR(50) NOT NULL," + // 'MST_1', 'MST_2', 'ASSIGNMENT_1', 'ASSIGNMENT_2'
                    "marks_obtained DOUBLE NOT NULL," +
                    "max_marks DOUBLE NOT NULL," +
                    "FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE," +
                    "FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE," +
                    "UNIQUE KEY unique_student_course_exam (student_id, course_id, exam_type)" +
                    ") ENGINE=InnoDB;";
            stmt.executeUpdate(createMarksTable);

            stmt.execute("SET FOREIGN_KEY_CHECKS = 1;");
            System.out.println("[INFO] All tables created successfully.");

            // Seed default courses
            seedDefaultCourses(conn);

            // Seed default faculty account if table is empty
            seedFacultyUser(conn);

        } catch (SQLException e) {
            throw new DatabaseException("Failed to initialize database tables", e);
        }
    }

    private static void seedDefaultCourses(Connection conn) throws SQLException {
        String[][] defaultCourses = {
                {"CS101", "Java Programming"},
                {"CS102", "Web Development"},
                {"CS103", "Database Management Systems"},
                {"CS104", "Software Engineering"}
        };
        
        String sql = "INSERT IGNORE INTO courses (course_code, course_name) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            for (String[] course : defaultCourses) {
                pstmt.setString(1, course[0]);
                pstmt.setString(2, course[1]);
                pstmt.executeUpdate();
            }
            System.out.println("[INFO] Seeded default courses (Java, Web Dev, DBMS, Software Eng).");
        }
    }

    private static void seedFacultyUser(Connection conn) throws SQLException {
        String checkFaculty = "SELECT COUNT(*) FROM users WHERE role = 'FACULTY'";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(checkFaculty)) {
            if (rs.next() && rs.getInt(1) == 0) {
                String seedSql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(seedSql)) {
                    pstmt.setString(1, "faculty");
                    pstmt.setString(2, "admin123");
                    pstmt.setString(3, "FACULTY");
                    pstmt.executeUpdate();
                    System.out.println("[INFO] Seeded default faculty account. Username: 'faculty', Password: 'admin123'");
                }
            }
        }
    }
}
