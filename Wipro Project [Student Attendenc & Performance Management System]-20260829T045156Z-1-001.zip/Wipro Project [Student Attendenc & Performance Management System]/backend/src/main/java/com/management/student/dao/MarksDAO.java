package com.management.student.dao;

import com.management.student.exception.DatabaseException;
import com.management.student.model.Marks;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles database operations for entering student marks course-wise.
 */
public class MarksDAO {

    public boolean saveOrUpdateMarks(Marks marks) throws DatabaseException {
        String sql = "INSERT INTO marks (student_id, course_id, exam_type, marks_obtained, max_marks) VALUES (?, ?, ?, ?, ?) " +
                     "ON DUPLICATE KEY UPDATE marks_obtained = ?, max_marks = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, marks.getStudentId());
            pstmt.setInt(2, marks.getCourseId());
            pstmt.setString(3, marks.getExamType());
            pstmt.setDouble(4, marks.getMarksObtained());
            pstmt.setDouble(5, marks.getMaxMarks());
            pstmt.setDouble(6, marks.getMarksObtained());
            pstmt.setDouble(7, marks.getMaxMarks());

            int rows = pstmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            throw new DatabaseException("Failed to save marks for student ID: " + marks.getStudentId(), e);
        }
    }

    public List<Marks> getMarksHistory(int studentId) throws DatabaseException {
        List<Marks> list = new ArrayList<>();
        String sql = "SELECT id, student_id, course_id, exam_type, marks_obtained, max_marks FROM marks WHERE student_id = ? ORDER BY course_id ASC, exam_type ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Marks marks = new Marks();
                    marks.setId(rs.getInt("id"));
                    marks.setStudentId(rs.getInt("student_id"));
                    marks.setCourseId(rs.getInt("course_id"));
                    marks.setExamType(rs.getString("exam_type"));
                    marks.setMarksObtained(rs.getDouble("marks_obtained"));
                    marks.setMaxMarks(rs.getDouble("max_marks"));
                    list.add(marks);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving marks history for student ID: " + studentId, e);
        }
        return list;
    }

    public List<Marks> getMarksHistoryForCourse(int studentId, int courseId) throws DatabaseException {
        List<Marks> list = new ArrayList<>();
        String sql = "SELECT id, student_id, course_id, exam_type, marks_obtained, max_marks FROM marks WHERE student_id = ? AND course_id = ? ORDER BY exam_type ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Marks marks = new Marks();
                    marks.setId(rs.getInt("id"));
                    marks.setStudentId(rs.getInt("student_id"));
                    marks.setCourseId(rs.getInt("course_id"));
                    marks.setExamType(rs.getString("exam_type"));
                    marks.setMarksObtained(rs.getDouble("marks_obtained"));
                    marks.setMaxMarks(rs.getDouble("max_marks"));
                    list.add(marks);
                }
            }
        } catch (SQLException e) {
            throw new DatabaseException("Error retrieving marks history for course", e);
        }
        return list;
    }
}
