package com.management.student.exception;

/**
 * Thrown when database operations fail.
 */
public class DatabaseException extends StudentManagementException {
    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
