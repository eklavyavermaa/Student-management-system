package com.management.student.controller;

import com.management.student.exception.DatabaseException;
import com.management.student.exception.InvalidDataException;
import com.management.student.model.Attendance;
import com.management.student.model.Student;
import com.management.student.service.AttendanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles REST endpoints for logging attendance and fetching shortage notification alerts.
 */
@RestController
@RequestMapping("/api/attendance")
@CrossOrigin(origins = "*")
public class AttendanceController {
    private final AttendanceService attendanceService = new AttendanceService();

    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getAttendanceHistory(@PathVariable("studentId") int studentId) {
        try {
            List<Attendance> list = attendanceService.getAttendanceHistory(studentId);
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/mark")
    public ResponseEntity<?> markAttendance(@RequestBody SingleAttendanceRequest request) {
        try {
            LocalDate date = request.date != null && !request.date.trim().isEmpty()
                    ? LocalDate.parse(request.date.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                    : LocalDate.now();

            attendanceService.markAttendance(request.studentId, request.courseId, date, request.status);
            return ResponseEntity.ok(new AuthController.MessageResponse("Attendance recorded successfully."));
        } catch (DateTimeParseException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse("Invalid date format. Use yyyy-MM-dd."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @PostMapping("/mark-batch")
    public ResponseEntity<?> markAttendanceBatch(@RequestBody BatchAttendanceRequest request) {
        try {
            LocalDate date = request.date != null && !request.date.trim().isEmpty()
                    ? LocalDate.parse(request.date.trim(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))
                    : LocalDate.now();

            attendanceService.markAttendanceBatch(request.studentStatusMap, request.courseId, date);
            return ResponseEntity.ok(new AuthController.MessageResponse("Batch attendance recorded successfully."));
        } catch (DateTimeParseException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse("Invalid date format. Use yyyy-MM-dd."));
        } catch (InvalidDataException e) {
            return ResponseEntity.status(400).body(new AuthController.ErrorResponse(e.getMessage()));
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    @GetMapping("/shortage-report")
    public ResponseEntity<?> getShortageReport() {
        try {
            Map<Student, Double> report = attendanceService.getAttendanceShortageReport();
            
            // Format report to a simpler list for frontend representation
            List<ShortageDTO> list = new ArrayList<>();
            for (Map.Entry<Student, Double> entry : report.entrySet()) {
                list.add(new ShortageDTO(entry.getKey(), entry.getValue()));
            }
            return ResponseEntity.ok(list);
        } catch (DatabaseException e) {
            return ResponseEntity.status(500).body(new AuthController.ErrorResponse(e.getMessage()));
        }
    }

    // --- DTOs ---
    public static class SingleAttendanceRequest {
        public int studentId;
        public int courseId;
        public String date;
        public String status;
    }

    public static class BatchAttendanceRequest {
        public int courseId;
        public String date;
        public Map<Integer, String> studentStatusMap; // StudentId -> Status
    }

    public static class ShortageDTO {
        private Student student;
        private double percentage;
        
        public ShortageDTO(Student student, double percentage) {
            this.student = student;
            this.percentage = percentage;
        }

        public Student getStudent() { return student; }
        public double getPercentage() { return percentage; }
    }
}
